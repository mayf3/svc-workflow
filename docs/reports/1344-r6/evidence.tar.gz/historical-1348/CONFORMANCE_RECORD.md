# WORKFLOW_WRITE_PATH_ENABLED_ENFORCEMENT_V1 implementation evidence

Implementation state: SOURCE COMMITTED at 8f5303e65c90c66ae89fa08755c377e975ef071b (tree a4b08728cb3a00b15fbb0c2a8fb5d0e27c46d51b). Verification state: PASS_WITH_KNOWN_1348_DEBT for this exact source tuple. All seven mapped changes, extended probes and the identical selected baseline/candidate suites have completed. No deployment, merge or production apply.

## Authority and exact coordinates

- Repository: mayf3/svc-workflow; worktree /tmp/sw-d6-fix; branch ac-write-path-enforce-impl.
- Implementation base/current authority snapshot: 3dab10f166596be4dc3397ee5dab273df1e60244.
- Accepted semantic Spec head: c6f1567fed7cc1c61377dce0a96971a0f53b892e; Spec SHA256 307ccbc6a0c30b34f063af4f2fe867fe21a9541b19e115c66b7b10bfdf368154.
- Owner acceptance: https://github.com/mayf3/svc-workflow/pull/117#issuecomment-6554628551, fetched live and retained in authority-acceptance-live.json. The Spec's authoring-phase frontmatter remains unchanged; this exact acceptance and main merge authorize contract reuse.
- Source candidate binding: candidate-source-final.json seven file hashes and candidate-source.patch SHA256 1eb75aacb7432cc8eb7afe1f1b7b3235baf69e92fb947ab6395ff2167f608dea. No authority or existing test changes.
- Route/mandate/runbook: PREFLIGHT-PLAN-RUNBOOK.md; REUSE / BRIEF / CONTROLLED / IMPLEMENTATION; original user task authorizes exactly seven checks, isolated fixtures and GitHub open-only delivery.
- Environment: owned disposable PostgreSQL cluster, loopback 55471, role swwpe, explicit TEST_DATABASE_URL/DATABASE_URL. Test-generated JWT keys are not disclosed. Original helper/fixture sources are pinned to the base. No Auth/forum/outbox external calls or delivery.

## Seven-by-seven evidence

| Gap | Actual baseline RED | Final-source GREEN | Transaction/replay proof |
| --- | --- | --- | --- |
| GAP-WPE-01 cancel Owner | fresh disabled actor request200 + successful receipt + business delta; assertion rc101 |403/principal_disabled; rc0 | COMPLETED403 + same-xmin denial; replay/re-enable/fault/ordering/restart verified |
| GAP-WPE-02 archive Owner | same discriminator200 after legal cancel setup; rc101 |403/principal_disabled; rc0 | same requirements independently verified |
| GAP-WPE-03 add member Owner | fresh disabled actor200/outcome=added; rc101 |403/principal_disabled; rc0 | same requirements; added/already_member and pre-receipt gates retained |
| GAP-WPE-04 remove member Owner | fresh disabled actor200/binding disabled; rc101 |403/principal_disabled; rc0 | same requirements; enabled Owner can still remove disabled target |
| GAP-WPE-05 system scheduler | enabled binding + disabled scheduler200/case opened; rc101 |403/principal_disabled; rc0 | HTTP and direct application/store delegate; status-aware failure replay; no new case/Event/outbox |
| GAP-WPE-06 Minimal ADVANCE creator | legal validated/published model2 graph, enabled actor + disabled creator200/new assignment; rc101 |422/assignee_resolution_failed; rc0 | COMPLETED422 + target-denial audit; no business delta; enabled nonprimary control |
| GAP-WPE-07 Minimal RETURN creator | legal graph and real RETURN references, disabled creator200/new assignment; rc101 |422/assignee_resolution_failed; rc0 | same requirements independently verified |

OBS-WPE-IMPL-001: red/results.json and seven original raw snapshots; RED_INDEPENDENT_READBACK.json verifies no receipt existed before each fresh key, the checked subject was disabled, a successful receipt was committed and actual business tables changed. It is not a compilation, harness or stale replay failure.

OBS-WPE-IMPL-002: extended/results.json contains 26 actual test-process results, all rc0: seven original probes, 11 controls, seven fault/ordering tests and one explicit separate-process restart test. The final source hashes match the implementation and probe worktrees. All ordinary failure paths produce the existing command-specific body and digest, no runtime/role-binding delta, and one correlated durable denial in the receipt transaction.

OBS-WPE-IMPL-003: extended/faults has 21 distinct injections (each gap audit exception, completion exception and suppressed-zero-row completion). Each returns existing503/service_unavailable and independently reads back equal complete before/after snapshots, including receipts, audit and business tables. Four new actor branches locally map completion infrastructure errors to StorageError; system/Minimal locally verify completed status/body/digest without changing old completion paths.

OBS-WPE-IMPL-004: fourteen ordering records contain actual pg_stat_activity/pg_locks/blocker witnesses. Disable-first uses a non-key UPDATE of enabled and observes the command waiting in SELECT enabled ... FOR SHARE, then refusal after disable commits. Command-first pauses after the new check, observes that same non-key UPDATE waiting for the command, commits200 before the disable. Both orders are independently covered for all seven logical cases. No claim is based only on a static SELECT or FK KEY SHARE.

OBS-WPE-IMPL-005: seven restart records bind different actual OS PIDs, new pool/router/JWKS process, identical request/old key and unchanged historical failed receipt/first-denial audit. Controls also cover same-key failure, re-enable old-key failure/fresh-key success, successful replay, different-body409, synthetic PROCESSING425 (explicitly labelled fixture), scheduler HTTP scope/role/OBO boundaries, coordinator governance, disabled historical cleanup and remove disabled target.

EVD-WPE-IMPL-001: OBS001→CTR-WPE-001..005; establishes actual mapped baseline counterexamples, not full product conformance. EVD-WPE-IMPL-002: OBS002..005→CTR-WPE-001..007/ACC-WPE-001..006; executed source/DB/HTTP-command/transaction relations at the exact manifest coordinates. Independent review is INDEPENDENT_REVIEW.json; it binds 139 raw JSON hashes. No missing result is assumed PASS.

## Regression and unchanged boundaries

Baseline selected 8 suites: lib 248 PASS / 4 exact #1348 known failures/1ignored; other seven suites 530/530 PASS (member 25 / runtime 452 / cancel_archive 27 / coordinator 8 / execution 8 / activation 9 / return projection 1). Candidate completed exactly the same eight suite/test names with identical outcomes: 778 passed, four same-name known failures and one pre-existing ignored per side (783 selected tests). See baseline/evaluated-commands.json, candidate/commands.json and REGRESSION_SUMMARY.json. No initial harness-attempt record is substituted for the formal evaluated result. Complete inventory compares 64 targets and 1,276 tests, with 8 business-name categories per module and globally diff empty. Raw SQL/audit/internal literal changes are disclosed in candidate/naming-comparison.json and independently reviewed; they are not described as an empty raw-literal diff.

Known #1348 names, unchanged and unfiltered:

- domain::definition::graph_tests::instance_input_key_covered_by_context_schema_passes
- domain::definition::graph_tests::invalid_json_schema_not_checked_by_graph_validation
- domain::definition::graph_tests::primary_to_done_is_advance
- domain::definition::graph_tests::valid_three_node_trunk_passes

The initial suite21 harness attempt failed before product entry because SQLx required DATABASE_URL while only TEST_DATABASE_URL was set. Its 27 original names/log/STOP marker and hashes remain in harness-attempt-1/; classification-receipt.json records the independently verified configuration cause. With both URLs explicitly isolated, baseline 21 passed 27/27. This attempt is not business RED and is not erased or excluded by test-name filtering.

PRECEDENT_PRESERVATION.json proves #115/#116 implementation heads are in the base; transition_validation.rs is byte-identical and the entire Legacy post-resolver enabled guard is unchanged. Their accepted prior passed evidence is preserved, not relabelled as a new run. The new branch is only Minimal creator-target resolution and does not add primary/TERMINATE/activation semantics. Fixed/Input helpers, model3 and authorized_actions boundaries remain unchanged; the existing runtime suite provides their directly dependent controls.

## Review and completion boundary

Independent source/extended-evidence review found 0 contract blockers. Final aggregation verify_evidence.py returned rc0. Tests were compiled before committing; the seven tested file hashes are identical to their final commit blobs, independently confirmed in REGRESSION_FINAL_HEAD_BINDING.json. Current main was freshly read as the same 3dab10f1 base, impact NONE. Final independent head/database readback is recorded separately in INDEPENDENT_REVIEW.json. GitHub delivery is open-only PR and #1344 seven-item backfill; production/business acceptance remains outside this task.

Final delivery: https://github.com/mayf3/svc-workflow/pull/118 (OPEN/unmerged), independent final-head review https://github.com/mayf3/svc-workflow/pull/118#issuecomment-6554968077 and seven-item backfill https://github.com/mayf3/agent-control/issues/1344#issuecomment-6554974809 were fetched after posting and read back with exact head and seven GAP rows. Local/remote head match and worktree is clean. See FINAL_DELIVERY_RECEIPT.json and FIXTURE_STOP_RECEIPT.json.

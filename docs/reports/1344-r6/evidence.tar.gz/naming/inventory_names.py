#!/usr/bin/env python3
"""Deterministic lexical naming evidence; no behavior proof or authority creation.

snapshot ROOT REV|WORKTREE OUT reads only git-tracked/bounded product source paths.
compare BASE_DIR CANDIDATE_DIR OUT compares declarations, actual references,
persistence names, schemas, supplemental types and raw literals independently.
"""
import argparse
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

PREFIXES = ('src/', 'migrations/', 'contracts/', 'sdk/typescript/src/')
CATEGORIES = ('commands', 'events', 'errors', 'scopes', 'roles_capabilities', 'persistent_entities', 'routes')
LEXER = re.compile(r'(?P<raw>r(?P<hash>\#*)".*?"(?P=hash))|(?P<str>"(?:\\.|[^"\\])*")|(?P<line>//[^\n]*)|(?P<block>/\*.*?\*/)', re.S)
Q = r'"(?:\\.|[^"\\])*"'


def logical_module(path):
    # Stable owning Rust modules, not physical helper files. Source file names
    # and line provenance remain in records.json and the reference appendix.
    for prefix, owner in (
        ('src/store/postgres/workflow_instance_repository/', 'store.workflow_instance_repository'),
        ('src/application/workflow_instance/', 'application.workflow_instance'),
        ('src/domain/workflow_instance/', 'domain.workflow_instance'),
        ('src/domain/definition/', 'domain.definition'),
        ('src/domain/provisioning/', 'domain.provisioning'),
        ('src/http/', 'http'),
        ('src/auth/', 'auth'),
        ('migrations/', 'storage.schema'),
        ('contracts/workflow-http/', 'workflow_http_contract'),
        ('sdk/typescript/src/', 'typescript_sdk'),
    ):
        if path.startswith(prefix):
            return owner
    return path.rsplit('/', 1)[0].replace('src/', '').replace('/', '.')


def git(root, *args):
    return subprocess.check_output(['git', *args], cwd=root)


def save(directory, name, value):
    (directory / name).write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n')


def lex(source):
    clean, kept, strings, cursor = [], [], [], 0
    for m in LEXER.finditer(source):
        before = source[cursor:m.start()]
        clean.append(before)
        kept.append(before)
        replacement = ''.join('\n' if c == '\n' else ' ' for c in m.group())
        cursor = m.end()
        if m.group('raw') is not None or m.group('str') is not None:
            strings.append((m.start(), m.group()))
            clean.append(replacement)
            kept.append(m.group())
        else:
            clean.append(replacement)
            kept.append(replacement)
    clean.append(source[cursor:])
    kept.append(source[cursor:])
    return ''.join(clean), ''.join(kept), strings


def block_end(source, start):
    depth, pos = 1, start
    while pos < len(source) and depth:
        if source[pos] == '{':
            depth += 1
        elif source[pos] == '}':
            depth -= 1
        pos += 1
    return pos


def unquote(raw):
    if raw.startswith('r'):
        return raw[raw.index('"') + 1:raw.rindex('"')]
    try:
        return json.loads(raw)
    except ValueError:
        return raw[1:-1]


def snapshot(root, revision, out):
    root, out = Path(root).resolve(), Path(out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    if revision == 'WORKTREE':
        paths = sorted(set(git(root, 'ls-files', '--cached', '--others', '--exclude-standard', '--', *PREFIXES).decode().splitlines()))
        head = git(root, 'rev-parse', 'HEAD').decode().strip()
        read = lambda p: (root / p).read_bytes()
    else:
        head = git(root, 'rev-parse', revision + '^{commit}').decode().strip()
        paths = git(root, 'ls-tree', '-r', '--name-only', head, '--', *PREFIXES).decode().splitlines()
        read = lambda p: git(root, 'show', head + ':' + p)
    sources, hashes = {}, {}
    for path in paths:
        if '/target/' in path or not path.startswith(PREFIXES):
            continue
        if revision == 'WORKTREE' and not (root / path).is_file():
            continue
        data = read(path)
        hashes[path] = hashlib.sha256(data).hexdigest()
        if path.endswith(('.rs', '.sql', '.yaml', '.json', '.ts')):
            sources[path] = data.decode()

    records, raw, supplemental, schemas = [], {}, {}, {}
    constants, error_names = {}, set()
    parsed = {}
    for path, source in sources.items():
        clean, kept, strings = lex(source) if path.endswith('.rs') else (source, source, [])
        parsed[path] = (clean, kept, strings)
        if not path.endswith('.rs'):
            continue
        error_names.update(re.findall(r'\benum\s+(\w*Error)\b', clean))
        for m in re.finditer(r'\bconst\s+(\w+)\s*:[^;=]*=\s*(' + Q + r')\s*;', kept):
            ident, literal = m.groups()
            category = ('commands' if 'COMMAND_TYPE' in ident else 'events' if 'EVENT_TYPE' in ident
                        else 'scopes' if 'SCOPE' in ident else 'roles_capabilities' if 'ROLE' in ident or 'CAPABILITY' in ident else None)
            if category:
                constants[ident] = (category, unquote(literal))

    def add(path, category, name, kind, offset, recognizer):
        if not name:
            return
        records.append({'module': path, 'category': category, 'name': name, 'kind': kind,
                        'line': sources[path].count('\n', 0, offset) + 1, 'recognizer': recognizer})

    for path, source in sources.items():
        clean, kept, strings = parsed[path]
        raw[path] = sorted(set(v for _, v in strings)) if path.endswith('.rs') else sorted(set(re.findall(r'"(?:\\.|[^"\\])*"|\x27[^\x27\n]*\x27', source)))
        if path.endswith('.rs'):
            supplemental[path] = sorted(set(kind + ':' + ident for kind, ident in re.findall(r'\b(struct|enum|type)\s+(\w+)', clean)))
            supplemental[path] += sorted(set('macro_enum:' + ident for ident in re.findall(r'\bmake_enum!\s*\(\s*(\w+)', clean)))
            for m in re.finditer(r'\b(struct|enum|type)\s+(\w+)', clean):
                kind, ident = m.groups()
                if ident.endswith('Command'):
                    add(path, 'commands', 'type:' + ident, 'definition', m.start(), 'command_type_declaration')
                if ident.endswith('EventData'):
                    add(path, 'events', 'type:' + ident, 'definition', m.start(), 'event_data_declaration')
            for m in re.finditer(r'\bconst\s+(\w+)\s*:[^;=]*=\s*(' + Q + r')\s*;', kept):
                if m.group(1) in constants:
                    cat, value = constants[m.group(1)]
                    add(path, cat, 'value:' + value, 'definition', m.start(), 'typed_constant')
                    add(path, cat, 'constant:' + m.group(1), 'definition', m.start(), 'constant_identifier')
            for ident, (cat, value) in constants.items():
                for m in re.finditer(r'\b' + re.escape(ident) + r'\b', clean):
                    add(path, cat, 'value:' + value, 'reference', m.start(), 'known_constant_use')
            for m in re.finditer(r'\benum\s+(\w*Error)\b[^\{]*\{', clean):
                ident, start = m.group(1), m.end()
                add(path, 'errors', 'type:' + ident, 'definition', m.start(), 'error_enum')
                depth, pos, variant_start = 1, start, True
                while pos < len(clean) and depth:
                    ch = clean[pos]
                    if depth == 1 and variant_start and (ch.isalpha() or ch == '_'):
                        variant = re.match(r'\w+', clean[pos:]).group()
                        add(path, 'errors', ident + '::' + variant, 'definition', pos, 'error_enum_variant')
                        variant_start = False
                    if ch in '{([':
                        depth += 1
                    elif ch in '})]':
                        depth -= 1
                    elif ch == ',' and depth == 1:
                        variant_start = True
                    pos += 1
            aliases = {m.group(2): m.group(1) for m in re.finditer(r'\buse\s+(\w*Error)\s+as\s+(\w+)\s*;', clean)}
            for m in re.finditer(r'\b(\w*Error|E|Error)\s*::\s*(\w+)', clean):
                error = aliases.get(m.group(1), m.group(1))
                if error in error_names:
                    add(path, 'errors', error + '::' + m.group(2), 'reference', m.start(), 'qualified_error_use')
            regions = [(0, len(source))] if path == 'src/http/error.rs' else []
            for m in re.finditer(r'\b(?:impl\s+\w*Error\b[^\{]*|fn\s+\w*error_(?:label|code)\b[^\{]*)\{', clean):
                regions.append((m.start(), block_end(clean, m.end())))
            for start, end in regions:
                for m in re.finditer(r'"([a-z][a-z0-9_]*)"', kept[start:end]):
                    add(path, 'errors', 'code:' + m.group(1), 'definition', start + m.start(), 'error_label_region')
            for m in re.finditer(r'\b(?:ApiError|Self)::(?:new|bad_request|unauthorized|unauthorized_with_details|service_unavailable|unprocessable)\s*\(\s*(?:StatusCode::\w+\s*,\s*)?"([a-z][a-z0-9_]*)"', kept):
                add(path, 'errors', 'code:' + m.group(1), 'reference', m.start(), 'api_error_constructor')
            for m in re.finditer(r'(?:require_scope|has_scope)\s*\([^)]*?"([A-Za-z0-9_.:-]+)"', kept):
                add(path, 'scopes', 'value:' + m.group(1), 'reference', m.start(), 'scope_call')
            for m in re.finditer(r'\.(?:route|nest)\s*\(\s*"([^"\n]+)"', kept):
                add(path, 'routes', m.group(1), 'definition' if path == 'src/http/mod.rs' else 'reference', m.start(), 'axum_route_or_nest')
            for m in re.finditer(r'"commandType"\s*:\s*"([A-Za-z0-9_.]+)"', kept):
                add(path, 'commands', 'value:' + m.group(1), 'reference', m.start(), 'inline_command_discriminator')
        if path.endswith(('.rs', '.sql')):
            # SQL includes Rust string contents; matches are preserved as a separate
            # reference surface and are not equated to persistent definitions.
            for m in re.finditer(r'\bCREATE\s+(TABLE|TYPE)\s+(?:IF\s+NOT\s+EXISTS\s+)?([A-Za-z_]\w*)', kept, re.I):
                add(path, 'persistent_entities', m.group(1).upper() + ':' + m.group(2), 'definition', m.start(), 'sql_create_entity')
            for m in re.finditer(r'\b(?:FROM|JOIN|UPDATE|INTO|REFERENCES|ALTER\s+TABLE|DELETE\s+FROM)\s+([A-Za-z_]\w*)', kept, re.I):
                # Only literal SQL entity spellings, avoiding prose/format tokens.
                if m.group(1).lower().startswith(('workflow_', 'principal', 'domain', 'definition_', 'security_', 'global_', 'command_', 'agent_', 'governance_')):
                    add(path, 'persistent_entities', 'relation:' + m.group(1), 'reference', m.start(), 'sql_relation_use')
            for m in re.finditer(r'\b(command_type|event_type)\s*=\s*\x27([A-Za-z0-9_.]+)\x27', kept):
                add(path, 'commands' if m.group(1) == 'command_type' else 'events', 'value:' + m.group(2), 'reference', m.start(), 'sql_discriminator')
            for m in re.finditer(r'["\x27](GLOBAL_[A-Z_]+|DOMAIN_OWNER|DOMAIN_MEMBER)["\x27]', kept):
                add(path, 'roles_capabilities', 'value:' + m.group(1), 'reference', m.start(), 'quoted_role_value')
        if path.endswith('openapi.yaml'):
            schema = {'component_names': [], 'operation_ids': [], 'paths': [], 'property_keys': [], 'enum_lines': [], 'refs': []}
            for i, line in enumerate(source.splitlines(), 1):
                if re.match(r'^    [A-Za-z_]\w*:\s*$', line):
                    schema['component_names'].append(line.strip()[:-1])
                m = re.match(r'^  (/.*):\s*$', line)
                if m:
                    schema['paths'].append(m.group(1)); add(path, 'routes', m.group(1), 'definition', source.find(line), 'openapi_path')
                m = re.match(r'^\s*operationId:\s*(\S+)', line)
                if m:
                    schema['operation_ids'].append(m.group(1))
                if re.match(r'^\s*(?:enum|const):', line):
                    schema['enum_lines'].append(line.strip())
                if '$ref:' in line:
                    schema['refs'].append(line.strip())
                m = re.match(r'^\s{8,}([A-Za-z_]\w*):', line)
                if m:
                    schema['property_keys'].append(m.group(1))
            schemas[path] = {k: sorted(set(v)) for k, v in schema.items()}
        elif path.endswith('.ts'):
            schemas[path] = {
                'declared_symbols': sorted(set(re.findall(r'\b(?:const|interface|type|class|enum)\s+(\w+)', source))),
                'object_keys': sorted(set(re.findall(r'^\s*([A-Za-z_]\w*)\s*:', source, re.M))),
                'zod_enum_literals': sorted(set(re.findall(r'z\.(?:enum|literal)\s*\(([^\n]+)', source))),
            }
        elif path.endswith('errors.json'):
            errors = json.loads(source).get('stable_codes', {})
            for values in errors.values():
                for code in values:
                    add(path, 'errors', 'code:' + code, 'definition', source.find('"' + code + '"'), 'contract_stable_error_code')

    records = sorted({json.dumps(x, sort_keys=True) for x in records})
    records = [json.loads(x) for x in records]
    def sets(kind):
        return {p: {c: sorted({r['name'] for r in records if r['module'] == p and r['category'] == c and (kind is None or r['kind'] == kind)}) for c in CATEGORIES} for p in sorted(sources)}
    for kind in ('definition', 'reference', None):
        label = kind or 'combined'
        per = sets(kind)
        save(out, label + '-per-module.json', per)
        save(out, label + '-global.json', {c: sorted({n for v in per.values() for n in v[c]}) for c in CATEGORIES})
    canonical_records = [r for r in records if r['kind'] == 'definition' or r['category'] in ('scopes', 'roles_capabilities')]
    owners = sorted({logical_module(p) for p in sources})
    canonical = {owner: {c: sorted({r['name'] for r in canonical_records if logical_module(r['module']) == owner and r['category'] == c}) for c in CATEGORIES} for owner in owners}
    save(out, 'canonical-per-logical-module.json', canonical)
    save(out, 'canonical-global.json', {c: sorted({n for v in canonical.values() for n in v[c]}) for c in CATEGORIES})
    save(out, 'records.json', records)
    save(out, 'raw-literals-per-module.json', raw)
    save(out, 'supplemental-rust-types.json', supplemental)
    save(out, 'wire-schema-symbols.json', schemas)
    save(out, 'source-hashes.json', hashes)
    save(out, 'coordinates.json', {'root': str(root), 'revision': revision, 'head': head,
                                  'evaluated_at_utc': datetime.now(timezone.utc).isoformat(),
                                  'file_count': len(hashes), 'source_count': len(sources),
                                  'status_porcelain': git(root, 'status', '--porcelain=v1').decode() if revision == 'WORKTREE' else None,
                                  'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                                  'global_combined_counts': {c: len({r['name'] for r in records if r['category'] == c}) for c in CATEGORIES}})
    save(out, 'SHA256SUMS.json', {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.glob('*.json')) if p.name != 'SHA256SUMS.json'})
    print(json.dumps({'output': str(out), 'head': head, 'files': len(hashes), 'records': len(records)}))


def differences(a, b):
    if isinstance(a, dict) and isinstance(b, dict):
        return {k: v for k in sorted(set(a) | set(b)) if (v := differences(a.get(k, {} if isinstance(b.get(k), dict) else []), b.get(k, {} if isinstance(a.get(k), dict) else [])))}
    return {k: v for k, v in {'removed': sorted(set(a) - set(b)), 'added': sorted(set(b) - set(a))}.items() if v}


def compare(base, candidate, out):
    base, candidate, out = Path(base), Path(candidate), Path(out)
    out.mkdir(parents=True, exist_ok=True)
    result = {}
    for name in ('canonical-per-logical-module', 'canonical-global'):
        result[name] = differences(json.loads((base / (name + '.json')).read_text()), json.loads((candidate / (name + '.json')).read_text()))
    for kind in ('definition', 'reference', 'combined'):
        for scope in ('per-module', 'global'):
            name = kind + '-' + scope
            result[name] = differences(json.loads((base / (name + '.json')).read_text()), json.loads((candidate / (name + '.json')).read_text()))
    for name in ('raw-literals-per-module', 'supplemental-rust-types', 'wire-schema-symbols'):
        result[name] = differences(json.loads((base / (name + '.json')).read_text()), json.loads((candidate / (name + '.json')).read_text()))
    ah, bh = json.loads((base / 'source-hashes.json').read_text()), json.loads((candidate / 'source-hashes.json').read_text())
    result['changed_source_paths'] = [k for k in sorted(set(ah) | set(bh)) if ah.get(k) != bh.get(k)]
    result['affected_logical_modules'] = sorted({logical_module(p) for p in result['changed_source_paths']})
    base_logical = json.loads((base / 'canonical-per-logical-module.json').read_text())
    candidate_logical = json.loads((candidate / 'canonical-per-logical-module.json').read_text())
    result['affected_canonical_baseline_sets'] = {m: base_logical.get(m, {}) for m in result['affected_logical_modules']}
    result['affected_canonical_candidate_sets'] = {m: candidate_logical.get(m, {}) for m in result['affected_logical_modules']}
    result['definition_name_diff_empty'] = not result['definition-per-module'] and not result['definition-global']
    result['canonical_name_diff_empty'] = not result['canonical-per-logical-module'] and not result['canonical-global']
    result['combined_name_diff_empty'] = not result['combined-per-module'] and not result['combined-global']
    result['global_combined_diff_empty'] = not result['combined-global']
    result['gate_disposition'] = 'REVIEW_REQUIRED; lexical equality does not itself prove semantic name closure'
    result['baseline_coordinates'] = json.loads((base / 'coordinates.json').read_text())
    result['candidate_coordinates'] = json.loads((candidate / 'coordinates.json').read_text())
    save(out, 'comparison.json', result)
    save(out, 'SHA256SUMS.json', {'comparison.json': hashlib.sha256((out / 'comparison.json').read_bytes()).hexdigest()})
    print(json.dumps({k: v for k, v in result.items() if k.endswith('_empty') or k == 'changed_source_paths'}))
    # Nonempty names never silently pass; caller must inspect and disposition.
    return 0 if result['canonical_name_diff_empty'] else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    snap = sub.add_parser('snapshot')
    for item in ('root', 'revision', 'output'):
        snap.add_argument(item)
    comp = sub.add_parser('compare')
    for item in ('baseline', 'candidate', 'output'):
        comp.add_argument(item)
    args = parser.parse_args()
    if args.command == 'snapshot':
        snapshot(args.root, args.revision, args.output)
    else:
        raise SystemExit(compare(args.baseline, args.candidate, args.output))

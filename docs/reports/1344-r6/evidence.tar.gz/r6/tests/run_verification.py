import datetime,hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
OUT=Path('/tmp/sw-aa-r6-evidence/tests'); ROOT=Path('/tmp/sw-aa-r5-tests'); PG='/opt/homebrew/Cellar/postgresql@16/16.15/bin/'
DSN='postgres://swaar4@127.0.0.1:55483/sw_aa_r4'; ENV=dict(os.environ,TEST_DATABASE_URL=DSN,DATABASE_URL=DSN,CARGO_TARGET_DIR='/tmp/sw-aa-r5-evidence/target',AA_RESULT_DIR=str(OUT/'frozen-green'),AA_SHARED_BASELINE='/tmp/sw-aa-r4-evidence/extended-red/shared-read-record.json',AA_REUSE_CANCELLED_RED='/tmp/sw-aa-r4-evidence/red/red-result.json')
RECORDS=[]
def run(label,argv,env=ENV):
 start=time.time(); log=OUT/(label+'.log')
 with log.open('w') as f: result=subprocess.run(argv,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
 content=log.read_text(); rec={'label':label,'argv':argv,'rc':result.returncode,'seconds':round(time.time()-start,3),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'failed_names':sorted(set(re.findall(r'^test (\S+) \.\.\. FAILED$',content,re.M))),'summary':re.findall(r'^test result:.*$',content,re.M)}
 RECORDS.append(rec);(OUT/'commands.json').write_text(json.dumps(RECORDS,indent=2)+'\n');(OUT/(label+'.rc')).write_text(str(result.returncode)+'\n');print(json.dumps(rec),flush=True);return rec,content
def dbs(label):
 r,t=run(label,[PG+'psql',DSN,'-Atc',"SELECT datname FROM pg_database WHERE datname='sw_aa_r4' OR datname LIKE 'aa_r4_%' OR datname LIKE 'sw_aa_r6_%' ORDER BY datname"])
 assert r['rc']==0
 names=t.splitlines();(OUT/(label+'.json')).write_text(json.dumps(names,indent=2)+'\n');return names
def cleanup(reason):
 names=dbs('stop-databases'); dump=OUT/'dumps';dump.mkdir(exist_ok=True); receipts=[]
 for db in names:
  dest=dump/(db+'.dump');rec,_=run('dump-'+db,[PG+'pg_dump','-Fc','-d',DSN.rsplit('/',1)[0]+'/'+db,'-f',str(dest)]); check,_=run('validate-'+db,[PG+'pg_restore','--list',str(dest)]);receipts.append({'db':db,'dump_rc':rec['rc'],'validate_rc':check['rc'],'sha256':hashlib.sha256(dest.read_bytes()).hexdigest() if dest.exists() else None})
 run('pg-stop',[PG+'pg_ctl','-D','/tmp/sw-aa-r4-evidence/pgdata','-m','fast','stop']);status,_=run('pg-status-after',[PG+'pg_ctl','-D','/tmp/sw-aa-r4-evidence/pgdata','status']);ready,_=run('pg-ready-after',[PG+'pg_isready','-h','127.0.0.1','-p','55483']);(OUT/'STOP_RECEIPT.json').write_text(json.dumps({'reason':reason,'dumps':receipts,'status_rc':status['rc'],'ready_rc':ready['rc'],'business_tests_stopped':True},indent=2)+'\n')
def stop(rec,content):
 (OUT/'UNEXPECTED_FAILURE.json').write_text(json.dumps(rec,indent=2)+'\n');print('SEMANTIC_STOP '+json.dumps(rec),flush=True);print(content[-12000:],flush=True);cleanup(rec['label']);sys.exit(1)
# Actual PG command opts are frozen from existing postmaster.opts, no initdb.
rec,t=run('pg-start',[PG+'pg_ctl','-D','/tmp/sw-aa-r4-evidence/pgdata','-l',str(OUT/'postgres.log'),'-o','-h 127.0.0.1 -p 55483 -k /tmp/sw-aa-r4-evidence/pgsocket','start'])
if rec['rc']:sys.exit(rec['rc'])
dbs('databases-before')
probes=[
'http::cancelled_true_edge_has_no_action_after_independent_allow_and_refuse',
'matrix::legal_edges_sort_complete_and_each_effect_executes_independently',
'matrix::assistance_open_escalate_resolve_matches_each_original_writer',
'matrix::lifecycle_owner_coordinator_archive_and_repeated_archive',
'matrix::scope_gate_priority_full_restricted_hidden_and_minimal2',
'matrix::return_zero_penultimate_and_cap_use_events_and_read_never_opens_case',
'preservation::exact_fixture_shared_reads_and_cti_bytes_remain_unchanged',
'preservation::successor_transition_permission_does_not_grant_raw_assignee_assistance',
'managed::managed_required_effect_and_real_waiting_producer_preserve_non_gate_return',
'managed::opted_in_source_ordinary_owner_actions_are_excluded_and_refused',
'guards::model3_legitimate_edges_payload_cas_and_replay_keep_original_rules',
'guards::revoked_definition_disables_transitions_but_keeps_independent_assistance_cancel',
'guards::disabled_target_and_disabled_caller_fail_closed',
'guards::replaced_owner_loses_cancel_while_new_owner_gets_current_authority',
'faults::missing_activation_is_consistency_error_even_without_execute_scope',
'faults::missing_required_storage_table_is_503_not_empty_success',
'snapshot::repeatable_read_authority_snapshot_is_pre_owner_replacement_then_rechecks',
'linked::linked_child_resolve_requires_actual_accepted_terminal_proof',
'review::managed_review_nonterminal_and_terminal_preserve_effect_and_payload_boundaries']
for i,name in enumerate(probes):
 rec,t=run(f'probe-{i+1:02}', ['cargo','test','--offline','--test','67_authorized_actions_r4',name,'--','--exact','--test-threads=1','--nocapture'])
 rec['exact_probe']=name;(OUT/'commands.json').write_text(json.dumps(RECORDS,indent=2)+'\n')
 if rec['rc']:stop(rec,t)
 assert '1 passed; 0 failed' in t,rec
 dbs(f'databases-after-probe-{i+1:02}')
(OUT/'PROBES_GREEN.json').write_text(json.dumps({'probe_count':len(probes),'names':probes,'all_rc_zero':True,'source_snapshot':'CANDIDATE_SOURCE_SNAPSHOT.json','root_head':'d9ebad8db87356eac128e1858ee8f8a2ba1eda73'},indent=2)+'\n');print('PROBES_GREEN_19',flush=True)

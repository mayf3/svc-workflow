# r6 prepared commands and coverage

Do not run dependent business tests until Root explicitly authorizes SDK GREEN continuation.

PG start (reuse same existing owned cluster; do not initdb):

```sh
/opt/homebrew/Cellar/postgresql@16/16.15/bin/pg_ctl -D /tmp/sw-aa-r4-evidence/pgdata -l /tmp/sw-aa-r6-evidence/tests/postgres.log -o '-h 127.0.0.1 -p 55483 -k /tmp/sw-aa-r4-evidence/pgsocket' start
```

Root must first synchronize the intended Rust candidate files into the isolated test worktree and bind SHA256 to the root source snapshot; never copy the test worktree's older product source back into Root.

Both URLs must be explicitly isolated. Compile command may reuse the existing Cargo target cache (not product state); then execute each exact test sequentially and stop on any new semantic failure. The shared/RED fixture envs reuse original durable records without replay.

```sh
TEST_DATABASE_URL=postgres://swaar4@127.0.0.1:55483/sw_aa_r4 DATABASE_URL=postgres://swaar4@127.0.0.1:55483/sw_aa_r4 CARGO_TARGET_DIR=/tmp/sw-aa-r5-evidence/target cargo test --offline --test 67_authorized_actions_r4 --no-run
```

Per-probe execution environment:

- TEST_DATABASE_URL=postgres://swaar4@127.0.0.1:55483/sw_aa_r4
- DATABASE_URL=postgres://swaar4@127.0.0.1:55483/sw_aa_r4
- CARGO_TARGET_DIR=/tmp/sw-aa-r5-evidence/target
- AA_RESULT_DIR=/tmp/sw-aa-r6-evidence/tests/frozen-green (create directory first)
- AA_SHARED_BASELINE=/tmp/sw-aa-r4-evidence/extended-red/shared-read-record.json
- AA_REUSE_CANCELLED_RED=/tmp/sw-aa-r4-evidence/red/red-result.json

Command per exact name from PREPARATION_RECEIPT.json: `cargo test --offline --test 67_authorized_actions_r4 NAME -- --exact --test-threads=1 --nocapture`. Do not run the whole binary if that would continue after a first failed probe.

Prepared coverage: frozen10 probes include cancelled+legacy-true, all three effects, assistance independently, lifecycle/Coordinator, scope/write gate/restricted/Minimal2, RETURN0/max-1/max, shared CTI byte/digest and all reads, canonical successor/raw-assignee separation, managed source-effect/real WAITING producer/non-gate/RETURN, opted-in ordinary Owner refusal. New9 add model3/CAS/RETURN payload/replay, revokedDefinition, disabled target/caller, Owner replacement, missingactivation, missingstorage503, concurrent Owner snapshot, linked child accepted/nonaccepted proof, managedREVIEW nonterminal/terminal and payload boundary. These are prepared definitions, not observations. Full ACC001..007 acceptance remains NOT_RUN.

Static coverage caution: concurrent case and RETURN changes are not separate new probes (only Owner concurrency); no new DRAFTDefinition probe, duplicateactivation probe or cleanupactor probe is explicitly visible in the19 names. Reviewer should decide sufficiency using accepted existing relevant evidence; do not infer unexecuted PASS. ACB/Context payload regression is represented by original relevant suites and managed gated-entry/Review probe, not a fresh dedicated generic ACB test here.

Naming command (after final edits) uses preserved `/tmp/sw-aa-r5-evidence/naming/inventory_names.py`: `snapshot /tmp/sw-d6-fix WORKTREE /tmp/sw-aa-r6-evidence/naming/candidate`, then `compare /tmp/sw-aa-r5-evidence/naming/baseline /tmp/sw-aa-r6-evidence/naming/candidate /tmp/sw-aa-r6-evidence/naming/comparison`. Require extractor hash equal c8850e9ea03aead52e6cfc2bcdeef9aa4614d7b574155b03c347ff81761ea50f; if changed, reextract both exactb32 and candidate. Canonical perlogicalmodule/global diff must be empty; raw/reference/wire differences need independent semantic review. ExistingSDK field correction belongs to explicit r6 mandate, not AAnewwire whitelist.

Existing test names: Root unchanged tests/Cargo/build.rs relative to exactb32 were observed by empty `git diff --name-only b32 -- tests Cargo.toml Cargo.lock build.rs`. This supports source preservation, not a fresh executed test inventory. Prior executed WPE1276/64 inventory is historical bound3dab only. Full fresh enumeration can use `cargo test --offline -- --list` with isolated URLs after explicit Root start; parser `/tmp/sw-wpe-evidence/baseline/parse_test_names.py` preserves full per-target/global names and zero-test targets. Record new19 overlay probe names separately; never filter or rename old names.

Prior required selected regression suites, if Root elects affected regressions: lib,17_workflow_runtime,18_self_projection_and_domain_members,21_instance_cancel_archive,28_visit_activation_v1,33_return_contract_projection,35_coordinator_control_plane,36_execution_control_v1. Prior WPE each side778pass/4sameknownfailed/1ignored across783 tests; do not describe this as a fresh r6 run. Known4 names are fully listed in PREPARATION_RECEIPT.json. Both DATABASE_URL and TEST_DATABASE_URL must be set to avoid prior SQLx harness-only failure.

After authorized test execution, preserve owned DB dumps with pg_dump customformat and validate pg_restore --list, then pg_ctl -m fast stop; read fresh statusrc3/isreadyrc2. Never alter production or another fixture cluster.

import datetime,hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
ROOT=Path('/tmp/sw-aa-r5-tests'); OUT=Path('/tmp/sw-aa-r6-evidence/tests/regression');OUT.mkdir(exist_ok=True)
PG='/opt/homebrew/Cellar/postgresql@16/16.15/bin/';BASE_DSN='postgres://swaar4@127.0.0.1:55483/sw_aa_r4'; DSN='postgres://swaar4@127.0.0.1:55483/sw_aa_r6_regression'
ENV=dict(os.environ,TEST_DATABASE_URL=DSN,DATABASE_URL=DSN,CARGO_TARGET_DIR='/tmp/sw-aa-r5-evidence/target')
SUITES=['lib','17_workflow_runtime','18_self_projection_and_domain_members','21_instance_cancel_archive','28_visit_activation_v1','33_return_contract_projection','35_coordinator_control_plane','36_execution_control_v1','25_workflow_assistance','26_workflow_assistance_http','44_governance_child','46_owner_obligations','41_acceptance_context_binding_v1','41_current_task_input']
KNOWN={'domain::definition::graph_tests::'+n for n in ['instance_input_key_covered_by_context_schema_passes','invalid_json_schema_not_checked_by_graph_validation','primary_to_done_is_advance','valid_three_node_trunk_passes']}
records=[]; summaries=[]
def run(label,argv):
 log=OUT/(label+'.log');start=time.time()
 with log.open('w') as f:r=subprocess.run(argv,cwd=ROOT,env=ENV,stdout=f,stderr=subprocess.STDOUT)
 text=log.read_text();rec={'label':label,'argv':argv,'rc':r.returncode,'seconds':round(time.time()-start,3),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'failed_names':sorted(set(re.findall(r'^test (\S+) \.\.\. FAILED$',text,re.M))),'summary':re.findall(r'^test result:.*$',text,re.M)};records.append(rec);(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');return rec,text
def fail(rec,text):
 (OUT/'UNEXPECTED_FAILURE.json').write_text(json.dumps(rec,indent=2)+'\n');print('SEMANTIC_STOP '+json.dumps(rec),flush=True);print(text[-12000:],flush=True)
 # All dependent tests stop before postfailure read/dump/controlled shutdown.
 code=Path('/tmp/sw-aa-r6-evidence/tests/run_verification.py').read_text().split('# Actual PG command')[0].replace("OUT=Path('/tmp/sw-aa-r6-evidence/tests')","OUT=Path('/tmp/sw-aa-r6-evidence/tests/regression')").replace("WHERE datname='sw_aa_r4' OR datname LIKE 'aa_r4_%' OR datname LIKE 'sw_aa_r6_%'","WHERE NOT datistemplate AND datname <> 'postgres'")
 namespace={};exec(compile(code,'verification_cleanup','exec'),namespace);namespace['RECORDS']=records;namespace['cleanup']('regression:'+rec['label']);sys.exit(1)
assert Path('/tmp/sw-aa-r6-evidence/tests/PROBES_GREEN.json').exists(),'all23 scoped probes must pass first'
run('all-cluster-databases-before',[PG+'psql',BASE_DSN,'-Atc',"SELECT datname FROM pg_database WHERE NOT datistemplate AND datname <> 'postgres' ORDER BY datname"])
rec,t=run('create-regression-db',[PG+'createdb','-h','127.0.0.1','-p','55483','-U','swaar4','sw_aa_r6_regression'])
if rec['rc']:fail(rec,t)
argv=['cargo','test','--offline','--no-run','--message-format=json','--lib']
for suite in SUITES[1:]:argv+=['--test',suite]
rec,compiler=run('compile-all',argv)
print(json.dumps(rec),flush=True)
if rec['rc']:fail(rec,compiler)
artifacts={}
for line in compiler.splitlines():
 try:a=json.loads(line)
 except:continue
 if a.get('reason')=='compiler-artifact' and a.get('executable') and a.get('profile',{}).get('test'):
  name='lib' if a['target']['kind']==['lib'] else a['target']['name']
  if name in SUITES:artifacts[name]={'path':a['executable'],'sha256':hashlib.sha256(Path(a['executable']).read_bytes()).hexdigest(),'source':a['target']['src_path']}
assert set(artifacts)==set(SUITES),(set(artifacts),SUITES)
(OUT/'binaries.json').write_text(json.dumps(artifacts,indent=2)+'\n')
inventory={}
for suite in SUITES:
 rec,t=run('list-'+suite,[artifacts[suite]['path'],'--list'])
 if rec['rc']:fail(rec,t)
 names=sorted(line[:-6] for line in t.splitlines() if line.endswith(': test'))
 inventory[suite]=names
(OUT/'tests-per-target.json').write_text(json.dumps(inventory,indent=2)+'\n');(OUT/'tests-global.json').write_text(json.dumps(sorted(suite+'::'+name for suite,names in inventory.items() for name in names),indent=2)+'\n')
print('FRESH_LIST '+json.dumps({'suites':len(inventory),'tests':sum(map(len,inventory.values()))}),flush=True)
for suite in SUITES:
 passed=ignored=0;known=[];start=time.time();suite_records=[]
 assert hashlib.sha256(Path(artifacts[suite]['path']).read_bytes()).hexdigest()==artifacts[suite]['sha256']
 for i,name in enumerate(inventory[suite]):
  rec,t=run(f'{suite}-{i+1:03}',[artifacts[suite]['path'],name,'--exact','--test-threads=1']);rec['test_name']=name;rec['suite']=suite;suite_records.append(rec)
  if rec['rc']:
   allowed=suite=='lib' and name in KNOWN and rec['rc']==101 and rec['failed_names']==[name]
   if not allowed:fail(rec,t)
   known.append(name)
  elif '0 passed; 0 failed; 1 ignored;' in t:ignored+=1
  else:
   if '1 passed; 0 failed;' not in t:fail(rec,t)
   passed+=1
 if suite=='lib' and set(known)!=KNOWN:fail({'label':'lib-known-failure-set-drift','expected':sorted(KNOWN),'actual':known},'Known failure set must be exact; no waiver inferred')
 summary={'suite':suite,'listed':len(inventory[suite]),'passed':passed,'known_failed':known,'ignored':ignored,'seconds':round(time.time()-start,3),'all_original_names_invoked':True,'invocation_method':'every listed test separately --exact; failfast before next test; no renamed/skipped tests','suite_single_process_rc':'NOT_APPLICABLE individual real process rc in commands.json'};summaries.append(summary);(OUT/'SUMMARY.json').write_text(json.dumps(summaries,indent=2)+'\n');(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print('SUITE_RESULT '+json.dumps(summary),flush=True)
 run('all-cluster-databases-after-'+suite,[PG+'psql',BASE_DSN,'-Atc',"SELECT datname FROM pg_database WHERE NOT datistemplate AND datname <> 'postgres' ORDER BY datname"])
(OUT/'GREEN_WITH_KNOWN_DEBT.json').write_text(json.dumps({'suites':summaries,'passed':sum(s['passed'] for s in summaries),'known_failed':sorted(KNOWN),'ignored':sum(s['ignored'] for s in summaries),'all_original_listed_names_invoked':True,'new_semantic_failures':0,'source_snapshot':'../CANDIDATE_SOURCE_SNAPSHOT.json','original_test_source_preservation':'../ORIGINAL_TEST_SOURCE_PRESERVATION.json'},indent=2)+'\n');print('REGRESSION_DONE_WITH_EXACT_1348_DEBT',flush=True)

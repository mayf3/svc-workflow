import datetime,hashlib,json,os,re,subprocess,sys,time,uuid
from pathlib import Path
BASE=Path('/tmp/sw-aa-r6-evidence/tests');ROOT=Path('/tmp/sw-aa-r5-tests');OUT=BASE/'remaining';OUT.mkdir(exist_ok=False);(OUT/'shared-dumps').mkdir();(OUT/'cti-http').mkdir()
PG=Path('/opt/homebrew/Cellar/postgresql@16/16.15/bin');SHARED='postgres://postgres@127.0.0.1:55432/postgres';OWNER='postgres://postgres@127.0.0.1:55432/svc_obl_20261029_impl';OWNED='postgres://swaar4@127.0.0.1:55483/postgres';DATA=Path('/tmp/sw-aa-r4-evidence/pgdata');EXPECTED_SHARED=Path('/Users/yanfenma/workspace/artifacts/workflow-unattended-mechanisms-20261027/pg55432-cluster')
records=[];new_shared={};summaries=[];owned_started=False;old_shared=None;artifact=json.loads((BASE/'regression/binaries.json').read_text());inventories=json.loads((BASE/'regression/tests-per-target.json').read_text())
ENV=dict(os.environ);ENV.pop('PGOPTIONS',None)
def run(label,argv,env=ENV):
 log=OUT/(label+'.log');start=time.time()
 with log.open('w') as f:r=subprocess.run(list(map(str,argv)),cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
 text=log.read_text();failed=sorted(set(re.findall(r'^test (\S+) \.\.\. FAILED$',text,re.M)))
 if not failed and r.returncode and 'failures:' in text:failed=re.findall(r'^    (\S+)\s*$',text[text.rfind('failures:'):],re.M)
 rec={'label':label,'argv':list(map(str,argv)),'rc':r.returncode,'seconds':round(time.time()-start,3),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'failed_names':failed,'summary':re.findall(r'^test result:.*$',text,re.M)};records.append(rec);(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');return rec,text
SQL="""SELECT jsonb_build_object('role',current_user,'address',inet_server_addr(),'port',inet_server_port(),'directory',current_setting('data_directory'),'read_only',current_setting('default_transaction_read_only'),'databases',(SELECT jsonb_agg(jsonb_build_object('name',datname,'oid',oid,'owner',pg_get_userbyid(datdba)) ORDER BY datname) FROM pg_database WHERE NOT datistemplate),'clients',(SELECT COALESCE(jsonb_agg(jsonb_build_object('pid',pid,'db',datname,'state',state)),'[]'::jsonb) FROM pg_stat_activity WHERE backend_type='client backend' AND pid<>pg_backend_pid()))"""
def shared_read(label):
 env=dict(ENV,PGOPTIONS='-c default_transaction_read_only=on');rec,text=run(label,[PG/'psql','-X','--no-password',SHARED,'-Atc',SQL],env);assert rec['rc']==0;text=json.loads(text);assert text['role']=='postgres' and text['address']=='127.0.0.1' and text['port']==55432 and text['read_only']=='on' and Path(text['directory']).resolve()==EXPECTED_SHARED.resolve();return text
def dbmap(state):return {r['name']:r for r in state['databases']}
def preserve_old(state):
 current=dbmap(state)
 for name,row in old_shared.items():assert current.get(name)==row,('preexisting database metadata changed',name)
 return current
def register(db,origin):
 assert db not in old_shared and db not in new_shared
 new_shared[db]={'origin':origin,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()};(OUT/'NEW_SHARED_DATABASES.json').write_text(json.dumps(new_shared,indent=2)+'\n')
def dump_shared(db):
 assert db in new_shared and db not in old_shared
 dest=OUT/'shared-dumps'/(db+'.dump');dump,_=run('shared-dump-'+db,[PG/'pg_dump','-Fc','-d',SHARED.rsplit('/',1)[0]+'/'+db,'-f',dest]);check,_=run('shared-validate-'+db,[PG/'pg_restore','--list',dest]);assert dump['rc']==check['rc']==0
 new_shared[db].update({'dump_rc':dump['rc'],'validation_rc':check['rc'],'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()});(OUT/'NEW_SHARED_DATABASES.json').write_text(json.dumps(new_shared,indent=2)+'\n')
def create_shared(db,origin):
 state=shared_read('shared-before-create-'+db);current=preserve_old(state);assert db not in current
 rec,text=run('create-shared-'+db,[PG/'createdb','-h','127.0.0.1','-p','55432','-U','postgres',db]);assert rec['rc']==0,text;register(db,origin)
def stop(rec,text):
 (OUT/'UNEXPECTED_FAILURE.json').write_text(json.dumps(rec,indent=2)+'\n');print('SEMANTIC_STOP '+json.dumps(rec),flush=True);print(text[-12000:],flush=True)
 for db in new_shared:dump_shared(db)
 state=shared_read('shared-final-readback-after-stop');preserve_old(state);(OUT/'BORROWED_SERVER_RETAINED.json').write_text(json.dumps({'state':state,'old_names_preserved':True,'lifecycle_mutation':False},indent=2)+'\n')
 if owned_started:
  code=(BASE/'run_verification.py').read_text().split('# Actual PG command')[0].replace("OUT=Path('/tmp/sw-aa-r6-evidence/tests')","OUT=Path('/tmp/sw-aa-r6-evidence/tests/remaining')").replace("WHERE datname='sw_aa_r4' OR datname LIKE 'aa_r4_%' OR datname LIKE 'sw_aa_r6_%'","WHERE NOT datistemplate AND datname <> 'postgres'")
  ns={};exec(compile(code,'owned_only_cleanup','exec'),ns);ns['RECORDS']=records;ns['cleanup'](rec['label'])
 sys.exit(1)
# Recheck exact unchanged product and old tests before borrowing any writes.
source=json.loads((BASE/'CANDIDATE_SOURCE_SNAPSHOT.json').read_text())['src_files'];assert {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'src').rglob('*')) if p.is_file()}==source
oldproof=json.loads((BASE/'ORIGINAL_TEST_SOURCE_PRESERVATION.json').read_text());assert all(hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==v['base_sha256'] for f,v in oldproof['files'].items())
rec,listener=run('shared-listener-readonly',['lsof','-nP','-iTCP:55432','-sTCP:LISTEN']);assert rec['rc']==0 and re.search(r'^postgres\s+48483\s',listener,re.M)
state=shared_read('shared-fresh-readonly-preflight');assert not state['clients'];old_shared=dbmap(state)
expected={line.split('|')[0] for line in (BASE/'shared-55432/ROOT_READONLY_PREFLIGHT.log').read_text().splitlines() if len(line.split('|'))==2};assert set(old_shared)==expected,(set(old_shared),expected)
assert 'svc_obl_20261029_impl' not in old_shared;(OUT/'SHARED_BASELINE.json').write_text(json.dumps(state,indent=2)+'\n')
create_shared('svc_obl_20261029_impl','Root-authorized empty anchor, not connected by original owner helper');dump_shared('svc_obl_20261029_impl')
for suite in ['46_owner_obligations','41_acceptance_context_binding_v1','41_current_task_input']:
 binary=Path(artifact[suite]['path']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==artifact[suite]['sha256'];rec,text=run('list-'+suite,[binary,'--list']);assert rec['rc']==0;names=sorted(line[:-6] for line in text.splitlines() if line.endswith(': test'));assert names==inventories[suite]
 if suite=='41_acceptance_context_binding_v1':
  rec,text=run('owned-pg-start',[PG/'pg_ctl','-D',DATA,'-l',OUT/'owned-postgres.log','-o','-h 127.0.0.1 -p 55483 -k /tmp/sw-aa-r4-evidence/pgsocket','start']);assert rec['rc']==0;text;owned_started=True
  acb_db='sw_aa_r6_acb_'+uuid.uuid4().hex;rec,text=run('create-owned-acb-db',[PG/'createdb','-h','127.0.0.1','-p','55483','-U','swaar4',acb_db]);assert rec['rc']==0;acb_dsn=OWNED.rsplit('/',1)[0]+'/'+acb_db;(OUT/'ACB_OWNED_DATABASE.json').write_text(json.dumps({'name':acb_db,'dsn':acb_dsn,'port':55483,'owned_cluster':True},indent=2)+'\n')
 start=time.time();passed=0
 for i,name in enumerate(names):
  assert hashlib.sha256(binary.read_bytes()).hexdigest()==artifact[suite]['sha256']
  if suite=='46_owner_obligations':dsn=OWNER;before=preserve_old(shared_read(f'owner-{i+1:02}-db-before'))
  elif suite=='41_current_task_input':
   db='svc_workflow_test_current_input_20261027_r6_'+uuid.uuid4().hex[:16];assert len(db)<=63;create_shared(db,'CTI exact '+name);dsn=SHARED.rsplit('/',1)[0]+'/'+db
  else:dsn=acb_dsn
  env=dict(ENV,TEST_DATABASE_URL=dsn,DATABASE_URL=dsn,CTI_HTTP_EVIDENCE_DIR=str(OUT/'cti-http'))
  rec,text=run(f'{suite}-{i+1:03}',[binary,name,'--exact','--test-threads=1','--nocapture'],env);rec.update({'suite':suite,'test_name':name,'TEST_DATABASE_URL':dsn,'DATABASE_URL':dsn,'binary_sha256':artifact[suite]['sha256']})
  if suite=='46_owner_obligations':
   after=preserve_old(shared_read(f'owner-{i+1:02}-db-after'));added=set(after)-set(before);reported=set(re.findall(r'fresh retained (?:isolated|predecessor) DB: (\w+)',text));assert added==reported,(added,reported)
   for new in sorted(added):
    assert re.fullmatch(r'svc_obl_(?:20261029|pred)_[0-9a-f]{32}',new),new;register(new,'46 exact '+name);dump_shared(new)
  elif suite=='41_current_task_input':dump_shared(db)
  (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
  if rec['rc']:stop(rec,text)
  if '1 passed; 0 failed;' not in text:stop(rec,text)
  passed+=1
 summary={'suite':suite,'listed':len(names),'passed':passed,'failed':0,'seconds':round(time.time()-start,3),'all_original_names_invoked':True,'binary_sha256':artifact[suite]['sha256']};summaries.append(summary);(OUT/'SUMMARY.json').write_text(json.dumps(summaries,indent=2)+'\n');print('SUITE_RESULT '+json.dumps(summary),flush=True)
state=shared_read('shared-final-identity-db-client-readback');preserve_old(state);assert not state['clients'];assert set(dbmap(state))==set(old_shared)|set(new_shared);(OUT/'BORROWED_SERVER_RETAINED.json').write_text(json.dumps({'state':state,'old_names_OIDs_owners_preserved':True,'old_database_bytes':'NOT_READ_NOT_CLAIMED','new_databases':new_shared,'server_lifecycle_mutation':False,'roles_configuration_mutation':False},indent=2)+'\n')
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'remaining108_passed':sum(s['passed'] for s in summaries),'suites':summaries,'old837_results_reused':True,'AA23_green_reused':True,'shared_new_db_count':len(new_shared),'all_shared_new_db_dumps_validated':all(r.get('dump_rc')==r.get('validation_rc')==0 for r in new_shared.values()),'borrowed_server_left_running_unchanged_lifecycle':True,'owned55483':'RUNNING_PENDING_ROOT_FINAL_DUMP_STOP','source_and_original_tests_unchanged':True};(OUT/'GREEN.json').write_text(json.dumps(result,indent=2)+'\n');print('REMAINING_108_PASS '+json.dumps(result),flush=True)

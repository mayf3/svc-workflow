import datetime,hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
BASE=Path('/tmp/sw-aa-r6-evidence/tests');OUT=BASE/'attempt4';OUT.mkdir(exist_ok=True);(OUT/'frozen-green').mkdir(exist_ok=True)
ROOT=Path('/tmp/sw-aa-r5-tests');PG='/opt/homebrew/Cellar/postgresql@16/16.15/bin/';DSN='postgres://swaar4@127.0.0.1:55483/sw_aa_r4'
ENV=dict(os.environ,TEST_DATABASE_URL=DSN,DATABASE_URL=DSN,AA_RESULT_DIR=str(OUT/'frozen-green'),AA_SHARED_BASELINE='/tmp/sw-aa-r4-evidence/extended-red/shared-read-record.json',AA_REUSE_CANCELLED_RED='/tmp/sw-aa-r4-evidence/red/red-result.json')
receipt=json.loads((BASE/'ATTEMPT4_COMPILE_RECEIPT.json').read_text());assert receipt['rc']==0;artifact=receipt['artifacts'][0];binary=Path(artifact['path']);RECORDS=[]
def run(label,argv):
 start=time.time();log=OUT/(label+'.log')
 with log.open('w') as f:r=subprocess.run(argv,cwd=ROOT,env=ENV,stdout=f,stderr=subprocess.STDOUT)
 text=log.read_text();failed=sorted(set(re.findall(r'^test (\S+) \.\.\. FAILED$',text,re.M)))
 if not failed and r.returncode and 'failures:' in text:failed=re.findall(r'^    (\S+)\s*$',text[text.rfind('failures:'):],re.M)
 rec={'label':label,'argv':argv,'rc':r.returncode,'seconds':round(time.time()-start,3),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'failed_names':failed,'summary':re.findall(r'^test result:.*$',text,re.M)};RECORDS.append(rec);(OUT/'commands.json').write_text(json.dumps(RECORDS,indent=2)+'\n');print(json.dumps(rec),flush=True);return rec,text
def fail(rec,text):
 (OUT/'UNEXPECTED_FAILURE.json').write_text(json.dumps(rec,indent=2)+'\n');print('SEMANTIC_STOP '+json.dumps(rec),flush=True);print(text[-16000:],flush=True)
 code=(BASE/'run_verification.py').read_text().split('# Actual PG command')[0].replace("OUT=Path('/tmp/sw-aa-r6-evidence/tests')","OUT=Path('/tmp/sw-aa-r6-evidence/tests/attempt4')")
 ns={};exec(compile(code,'attempt4cleanup','exec'),ns);ns['RECORDS']=RECORDS;ns['cleanup'](rec['label']);sys.exit(1)
def check_binary():assert hashlib.sha256(binary.read_bytes()).hexdigest()==artifact['sha256'],'physical executable changed; tooling HOLD'
check_binary();rec,t=run('actual-compiled-list',[str(binary),'--list']);assert rec['rc']==0;listed=sorted(line[:-6] for line in t.splitlines() if line.endswith(': test'));assert len(listed)==23; (OUT/'compiled-probes.json').write_text(json.dumps(listed,indent=2)+'\n')
rec,t=run('pg-start',[PG+'pg_ctl','-D','/tmp/sw-aa-r4-evidence/pgdata','-l',str(OUT/'postgres.log'),'-o','-h 127.0.0.1 -p 55483 -k /tmp/sw-aa-r4-evidence/pgsocket','start']);assert rec['rc']==0
rec,t=run('databases-before',[PG+'psql',DSN,'-Atc',"SELECT datname FROM pg_database WHERE datname='sw_aa_r4' OR datname LIKE 'aa_r4_%' OR datname LIKE 'sw_aa_r6_%' ORDER BY datname"]);assert rec['rc']==0
probes=[('probe-23', 'coverage_cleanup::retired_managed_cleanup_actor_is_projected_only_with_existing_full_visibility')]
for label,name in probes:
 assert name in listed;check_binary();rec,t=run(label,[str(binary),name,'--exact','--test-threads=1','--nocapture']);rec['exact_probe']=name;rec['binary_sha256']=artifact['sha256'];(OUT/'commands.json').write_text(json.dumps(RECORDS,indent=2)+'\n')
 if rec['rc']:fail(rec,t)
 assert '1 passed; 0 failed;' in t;check_binary()
 run('databases-after-'+label,[PG+'psql',DSN,'-Atc',"SELECT datname FROM pg_database WHERE datname='sw_aa_r4' OR datname LIKE 'aa_r4_%' OR datname LIKE 'sw_aa_r6_%' ORDER BY datname"])
summary={'all_23_current_probes_green':True,'first22_evidence':'attempt1 commands probe01..10, attempt2 probe11..16, attempt3 probe17..22; unchanged product src and unchanged successful probe helpers','attempt4_probe23':probes,'binary':artifact,'compile_receipt':'ATTEMPT4_COMPILE_RECEIPT.json','test_source_snapshot':'ATTEMPT4_TEST_SOURCE_SNAPSHOT.json','harness_only_corrections':'probe11 mandatoryaudit,17waiterselector,23creatorrestricted precondition, independently reviewed; no product edit','original_harness_failures_retained':'attempt1 probe11/attempt2 probe17/attempt3 probe23, all independently attributed HARNESS_ONLY; rawlogs/stopreceipts preserved'};(OUT/'GREEN.json').write_text(json.dumps(summary,indent=2)+'\n');(BASE/'PROBES_GREEN.json').write_text(json.dumps(summary,indent=2)+'\n');print('PROBES_GREEN_23_WITH_REUSED_FIRST22',flush=True)

from pathlib import Path
import json,hashlib,subprocess,os,datetime
root=Path('/tmp/sw-aa-r5-tests');out=Path('/tmp/sw-aa-r6-evidence/tests');snapshot=json.loads((out/'CANDIDATE_SOURCE_SNAPSHOT.json').read_text())
actual={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'src').rglob('*')) if p.is_file()};assert actual==snapshot['src_files']
files=[root/'tests/67_authorized_actions_r4.rs',*sorted((root/'tests/authorized_actions_r4').glob('*.rs'))]
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'product_src_unchanged':True,'source_snapshot':'CANDIDATE_SOURCE_SNAPSHOT.json','coverage_patch_sha256':hashlib.sha256(Path('/tmp/sw-aa-r6-evidence/review/coverage-probes.patch').read_bytes()).hexdigest(),'guards_patch_sha256':hashlib.sha256((out/'guards-audit-harness.patch').read_bytes()).hexdigest(),'snapshot_patch_sha256':hashlib.sha256((out/'snapshot-observer-harness.patch').read_bytes()).hexdigest(),'test_files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'business_started':False,'PG':'STOPPED'}
(out/'ATTEMPT3_TEST_SOURCE_SNAPSHOT.json').write_text(json.dumps(r,indent=2)+'\n')
argv=['cargo','test','--offline','--test','67_authorized_actions_r4','--no-run','--message-format=json'];env=dict(os.environ,TEST_DATABASE_URL='postgres://swaar4@127.0.0.1:55483/sw_aa_r4',DATABASE_URL='postgres://swaar4@127.0.0.1:55483/sw_aa_r4',CARGO_TARGET_DIR='/tmp/sw-aa-r5-evidence/target')
with (out/'attempt3-compile.log').open('w') as stream:result=subprocess.run(argv,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
(out/'attempt3-compile.rc').write_text(str(result.returncode)+'\n')
artifacts=[]
for line in (out/'attempt3-compile.log').read_text().splitlines():
 try:a=json.loads(line)
 except:continue
 if a.get('reason')=='compiler-artifact' and a.get('executable') and a['target']['name']=='67_authorized_actions_r4':artifacts.append({'path':a['executable'],'sha256':hashlib.sha256(Path(a['executable']).read_bytes()).hexdigest(),'source':a['target']['src_path']})
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'rc':result.returncode,'log_sha256':hashlib.sha256((out/'attempt3-compile.log').read_bytes()).hexdigest(),'artifacts':artifacts,'source_snapshot':'ATTEMPT3_TEST_SOURCE_SNAPSHOT.json','business_tests_started':False,'PG':'STOPPED'};(out/'ATTEMPT3_COMPILE_RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if result.returncode:print((out/'attempt3-compile.log').read_text()[-6500:])
raise SystemExit(result.returncode)

"""Run only after Root explicitly requests final owned-fixture dump/stop."""
import datetime,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/tmp/sw-aa-r5-tests');OUT=Path('/tmp/sw-aa-r6-evidence/tests/final-fixture');OUT.mkdir(exist_ok=False);(OUT/'dumps').mkdir()
PG=Path('/opt/homebrew/Cellar/postgresql@16/16.15/bin');DATA=Path('/tmp/sw-aa-r4-evidence/pgdata');DSN='postgres://swaar4@127.0.0.1:55483/postgres';records=[]
def run(label,argv):
 log=OUT/(label+'.log')
 with log.open('w') as stream:r=subprocess.run(list(map(str,argv)),cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
 text=log.read_text();rec={'label':label,'argv':list(map(str,argv)),'rc':r.returncode,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};records.append(rec);(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');return rec,text
r,text=run('verify-data-directory',[PG/'psql',DSN,'-Atc','SHOW data_directory']);assert r['rc']==0 and Path(text.strip()).resolve()==DATA.resolve()
r,text=run('all-database-inventory',[PG/'psql',DSN,'-Atc',"SELECT COALESCE(jsonb_agg(jsonb_build_object('database',datname,'template',datistemplate,'owner',pg_get_userbyid(datdba)) ORDER BY datname),'[]'::jsonb) FROM pg_database"]);assert r['rc']==0;inventory=json.loads(text);(OUT/'DATABASE_INVENTORY.json').write_text(json.dumps(inventory,indent=2)+'\n')
r,text=run('remaining-client-activity',[PG/'psql',DSN,'-Atc',"SELECT COALESCE(jsonb_agg(jsonb_build_object('pid',pid,'database',datname,'user',usename,'state',state,'wait_event',wait_event,'query',query) ORDER BY pid),'[]'::jsonb) FROM pg_stat_activity WHERE backend_type='client backend' AND pid<>pg_backend_pid()"]);assert r['rc']==0;activity=json.loads(text);(OUT/'REMAINING_ACTIVITY.json').write_text(json.dumps(activity,indent=2)+'\n');assert not activity,'do not dump/stop over another live client; report exact activity to Root'
receipts=[]
for row in inventory:
 if row['template']:continue
 db=row['database'];dest=OUT/'dumps'/(db+'.dump');dump,_=run('dump-'+db,[PG/'pg_dump','-Fc','-d',DSN.rsplit('/',1)[0]+'/'+db,'-f',dest]);check,_=run('validate-'+db,[PG/'pg_restore','--list',dest]);receipts.append({'database':db,'dump_rc':dump['rc'],'validation_rc':check['rc'],'bytes':dest.stat().st_size if dest.exists() else None,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest() if dest.exists() else None})
stop,_=run('pg-stop',[PG/'pg_ctl','-D',DATA,'-m','fast','stop']);status,_=run('pg-status-after',[PG/'pg_ctl','-D',DATA,'status']);ready,_=run('pg-isready-after',[PG/'pg_isready','-h','127.0.0.1','-p','55483'])
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actor':'/root/test_prep','scope':'Root-authorized final dump/readback/owned PG shutdown only; no business commands','PGDATA':str(DATA),'port':55483,'inventory':'DATABASE_INVENTORY.json','all_nontemplate_DBs_including_postgres_admin':len(receipts),'remaining_clients_before_dump':activity,'dumps':receipts,'all_dump_and_validation_rc_zero':all(r['dump_rc']==r['validation_rc']==0 for r in receipts),'stop_rc':stop['rc'],'status_after_rc':status['rc'],'ready_after_rc':ready['rc'],'production_writes':False,'deployment':False};(OUT/'FINAL_FIXTURE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));assert receipt['all_dump_and_validation_rc_zero'] and stop['rc']==0 and status['rc']==3 and ready['rc']==2

from pathlib import Path
import subprocess, json, hashlib, datetime, re, copy
import yaml,jsonschema
repo=Path('/tmp/sw-d6-fix'); ev=Path('/tmp/sw-aa-r6-evidence/schema'); base='b32c0d1a82abeafbf993c5638bbc9f55e436d9a1'
def old(path): return subprocess.check_output(['git','show',f'{base}:{path}'],cwd=repo)
def sha(b): return hashlib.sha256(b).hexdigest()
paths=['contracts/workflow-http/v1/openapi.yaml','contracts/workflow-http/v1/manifest.json','contracts/workflow-http/v1/compatibility.md','contracts/workflow-http/v1/changelog.md','contracts/workflow-http/v1/contract.md','sdk/typescript/src/schemas.ts','sdk/typescript/src/types.ts','sdk/typescript/src/constants.ts','src/application/workflow_instance/authorized_actions.rs','src/application/workflow_instance/query_types.rs','src/store/postgres/workflow_instance_repository/query_detail.rs','src/store/postgres/workflow_instance_repository/query_worklists.rs','src/store/postgres/workflow_instance_repository/current_task_input.rs']
paths=[p for p in paths if (repo/p).is_file()]
hashes={p:sha((repo/p).read_bytes()) for p in paths}
oas_path='contracts/workflow-http/v1/openapi.yaml'; raw=(repo/oas_path).read_bytes(); doc=yaml.safe_load(raw); bdoc=yaml.safe_load(old(oas_path)); schemas=doc['components']['schemas']; orig=bdoc['components']['schemas']
assert doc['paths']==bdoc['paths'], 'path/operation drift'
changed={n for n in orig if schemas.get(n)!=orig[n]}
assert changed=={'WorkflowInstanceDetailResponse'},changed
added=set(schemas)-set(orig)
assert added=={'InstanceDetailWithAuthorizedActionsV1','AuthorizedActionV1','CurrentTaskTypeV1','HistoricalParticipantInstanceDetail','HistoricalParticipantSummary'},added
full=schemas['FullWorkflowInstanceDetail']; endpoint=schemas['InstanceDetailWithAuthorizedActionsV1']
assert full==orig['FullWorkflowInstanceDetail']
expected={'instance','current_context_revision_id','current_node_visit_id','current_context','current_visit','outgoing_transitions','authorized_actions_scope','authorized_actions_status','authorized_actions','current_task_type'}
assert set(endpoint['properties'])==set(endpoint['required'])==expected
assert endpoint['additionalProperties'] is False
for field,value in full['properties'].items(): assert endpoint['properties'][field]==value,(field,'changed legacy schema')
assert endpoint['properties']['authorized_actions_scope']['enum']==['INSTANCE_TASK_AND_GOVERNANCE_V1']
assert endpoint['properties']['authorized_actions_status']['enum']==['AVAILABLE','NONE_FOR_ACTOR','MISSING_EXECUTE_SCOPE','WRITE_GATE_CLOSED','UNSUPPORTED_MODEL']
assert endpoint['properties']['authorized_actions']['items']=={'$ref':'#/components/schemas/AuthorizedActionV1'}
variant_keys={'transition':{'operation','transition_id','transition_effect','request_validation'},'request_assistance':{'operation','request_validation'},'escalate_assistance':{'operation','assistance_case_id','request_validation'},'resolve_assistance':{'operation','assistance_case_id','request_validation'},'cancel':{'operation','request_validation'},'archive':{'operation','request_validation'}}
variants=schemas['AuthorizedActionV1']['oneOf']; assert len(variants)==6
for v,operation in zip(variants,variant_keys):
 assert v['additionalProperties'] is False
 assert set(v['properties'])==set(v['required'])==variant_keys[operation]
 assert v['properties']['operation']['enum']==[operation]
 assert v['properties']['request_validation']['enum']==['REQUIRED_AT_EXECUTION']
 for name in {'transition_id','assistance_case_id'}&set(v['properties']): assert v['properties'][name]=={'type':'string','format':'uuid'}
assert variants[0]['properties']['transition_effect']['enum']==['ADVANCE','RETURN','TERMINATE']
current=schemas['CurrentTaskTypeV1']; assert current['additionalProperties'] is False
assert set(current['required'])==set(current['properties'])=={'source','node_type','business_task_type'}
assert current['properties']['source']['enum']==['CURRENT_NODE_TYPE']
assert current['properties']['node_type']['enum']==['DRAFT','NORMAL','TASK','TERMINAL']
assert current['properties']['business_task_type']=={'type':'string','nullable':True,'enum':[None]}
branches=schemas['WorkflowInstanceDetailResponse']['oneOf']; assert len(branches)==2
for v,visibility,target in zip(branches,['full','historical_participant'],['InstanceDetailWithAuthorizedActionsV1','HistoricalParticipantInstanceDetail']):
 assert v['additionalProperties'] is False
 assert set(v['properties'])==set(v['required'])=={'visibility','detail'}
 assert v['properties']['visibility']['enum']==[visibility]
 assert v['properties']['detail']=={'$ref':f'#/components/schemas/{target}'}
restricted=schemas['HistoricalParticipantInstanceDetail']; assert restricted['additionalProperties'] is False
assert set(restricted['properties'])==set(restricted['required'])=={'instance'}
summary=schemas['HistoricalParticipantSummary']; assert summary['additionalProperties'] is False
assert set(summary['properties'])==set(summary['required'])=={'workflow_instance_id','domain_id','definition_version_id','definition_version_status','workflow_state_version','created_at','domain_enabled','is_terminal','current_node'}
assert 'created_by_principal_id' not in summary['properties']
def block(text,name):
 start=text.index('    '+name+':\n'); m=re.search(r'^    [A-Za-z][A-Za-z0-9_]*:\n',text[start+1:],re.M); end=start+1+m.start() if m else len(text); return text[start:end]
shared_block=block(raw.decode(),'FullWorkflowInstanceDetail')
assert shared_block==block(old(oas_path).decode(),'FullWorkflowInstanceDetail')
sdk=(repo/'sdk/typescript/src/schemas.ts').read_text(); bsdk=old('sdk/typescript/src/schemas.ts').decode()
def sdkblock(txt,start,end): return txt[txt.index(start):txt.index(end,txt.index(start))]
# SDK current_visit alignment is authored by this reviewer and is excluded from independent approval.
shared_sdk=sdkblock(sdk,'export const fullWorkflowInstanceDetailSchema','export const authorizedActionV1Schema')
old_shared_sdk=sdkblock(bsdk,'export const fullWorkflowInstanceDetailSchema','export const historicalParticipantSummarySchema')
assert shared_sdk==old_shared_sdk
restricted_sdk=sdkblock(sdk,'export const historicalParticipantSummarySchema','export const workflowInstanceDetailResponseSchema')
assert restricted_sdk==sdkblock(bsdk,'export const historicalParticipantSummarySchema','export const workflowInstanceDetailResponseSchema')
assert all((repo/p).read_bytes()==old(p) for p in ['src/application/workflow_instance/query_types.rs','src/store/postgres/workflow_instance_repository/query_detail.rs','src/store/postgres/workflow_instance_repository/query_worklists.rs'])
# Convert OpenAPI nullable to JSON Schema only for local wire-instance checks.
def convert(v):
 if isinstance(v,list): return [convert(x) for x in v]
 if not isinstance(v,dict): return v
 out={k:convert(x) for k,x in v.items() if k!='nullable'}
 if v.get('nullable') and 'type' in out: out['type']=[out['type'],'null']
 return out
js=convert(doc)
fixture=json.loads((repo/'sdk/typescript/tests/fixtures/current-detail.actual.json').read_text())
full_detail=copy.deepcopy(fixture['detail']); full_detail.update(authorized_actions_scope='INSTANCE_TASK_AND_GOVERNANCE_V1',authorized_actions_status='AVAILABLE',authorized_actions=[{'operation':'transition','transition_id':fixture['detail']['outgoing_transitions'][0]['transition_id'],'transition_effect':'ADVANCE','request_validation':'REQUIRED_AT_EXECUTION'}],current_task_type={'source':'CURRENT_NODE_TYPE','node_type':'TASK','business_task_type':None})
validator=jsonschema.Draft7Validator({'$ref':'#/components/schemas/WorkflowInstanceDetailResponse',**js},format_checker=jsonschema.FormatChecker())
assert validator.is_valid({'visibility':'full','detail':full_detail})
invalid=[]
for field in expected-set(full['properties']):
 d=copy.deepcopy(full_detail); del d[field]; invalid.append({'visibility':'full','detail':d})
invalid.append({'visibility':'full','detail':{**full_detail,'extra':True}})
invalid.append({'visibility':'full','detail':{**full_detail,'authorized_actions':[{'operation':'cancel','request_validation':'REQUIRED_AT_EXECUTION','transition_id':fixture['detail']['outgoing_transitions'][0]['transition_id']}]}})
invalid.append({'visibility':'full','detail':{**full_detail,'current_task_type':{'source':'CURRENT_NODE_TYPE','node_type':'TASK','business_task_type':'review'}}})
summary_fixture={k:v for k,v in fixture['detail']['instance'].items() if k in summary['properties']}
restricted_wire={'visibility':'historical_participant','detail':{'instance':summary_fixture}}
assert validator.is_valid(restricted_wire)
invalid.append({'visibility':'historical_participant','detail':{**restricted_wire['detail'],'authorized_actions':[]}})
invalid.append({'visibility':'historical_participant','detail':{'instance':{**summary_fixture,'created_by_principal_id':fixture['detail']['instance']['created_by_principal_id']}}})
assert all(not validator.is_valid(x) for x in invalid)
manifest=json.loads((repo/'contracts/workflow-http/v1/manifest.json').read_bytes()); constants=(repo/'sdk/typescript/src/constants.ts').read_text()
assert doc['info']['version']==manifest['contract_version']=='1.9.0'
assert f"CONTRACT_VERSION = '{manifest['contract_version']}'" in constants
assert manifest['bundle_digest'] in constants and manifest['owner_head_sha'] in constants
actual_tree=subprocess.check_output(['git','rev-parse',manifest['owner_head_sha']+'^{tree}'],cwd=repo,text=True).strip()
assert actual_tree==manifest['owner_tree_sha']
mainline=re.search(r"CONTRACT_MAINLINE_HEAD_SHA\s*=\s*'([0-9a-f]+)'",constants).group(1)
old_bundle_equal=all(subprocess.check_output(['git','show',mainline+':contracts/workflow-http/v1/'+p],cwd=repo)==(repo/'contracts/workflow-http/v1'/p).read_bytes() for p in manifest['bundle_file_set'])
assert hashes=={p:sha((repo/p).read_bytes()) for p in paths},'candidate changed during check'
result={'result':'PASS_FOR_AA_SCHEMA_STRUCTURE_AND_COMPATIBILITY; DELIVERY_POINTER_PENDING','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/sdk_align','independence':'independent for AA OpenAPI/SDK AA additions/bundle only; SDK two-field alignment author, no self-review approval of it','review_target_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'candidate':'HEAD plus source hashes','base_head':base,'schema_fields':sorted(expected),'action_variants':list(variant_keys),'changed_preexisting_schemas':sorted(changed),'added_schemas':sorted(added),'shared_openapi_block_sha256':sha(shared_block.encode()),'shared_sdk_block_sha256':sha(shared_sdk.encode()),'restricted_sdk_block_sha256':sha(restricted_sdk.encode()),'jsonschema_wire_checks':{'valid_samples':2,'rejected_samples':len(invalid),'note':'OpenAPI nullable converted to JSON Schema for pure wire-instance checks; not a whole-document OpenAPI meta-schema certification'},'unchanged_runtime_sources':['query_types.rs','query_detail.rs','query_worklists.rs'],'runtime_byte_claim':'NOT_VERIFIED_BY_THIS_REVIEW; root real HTTP shared fixture acceptance is separately required','metadata':{'contract_version':manifest['contract_version'],'owner_head_sha':manifest['owner_head_sha'],'owner_tree_sha':actual_tree,'schema_digest':manifest['schema_digest'],'bundle_digest':manifest['bundle_digest'],'contract_mainline_head_sha':mainline,'pointer_bundle_bytes_equal':old_bundle_equal,'required_closure':'After bundle commit A, constants commit B must set CONTRACT_MAINLINE_HEAD_SHA=A; recheck every declared bundle file byte at A equals final bundle'},'file_sha256':hashes}
(ev/'STRUCTURAL_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))

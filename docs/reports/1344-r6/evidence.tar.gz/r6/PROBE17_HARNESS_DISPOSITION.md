# Probe17 synchronization disposition

Attempt2 probe11 corrected audit assertion passed, then12..16 passed. Probe17 panicked at snapshot.rs11 while waiting for a test barrier observation. It did not execute Owner mutation at13 or semantic assertions at14 onward. Rawlog SHA25625eb6eda933593228431e4fcc73cc36704824158591db2289a5fa0c427c34fd1 is preserved.

Read-only source review and independent review identify a self-contradicting test selector: authorized_snapshot calls validate_all_facts before build_full. That integrity query LEFT JOINs workflow_transition_definitions, so the test's ACCESS EXCLUSIVE table lock blocks it before the later query containing the FROM text the test waits for. query_visibility is byte-identical to base. RR actor SELECT/visibility precedes this integrity query, making it a valid snapshot barrier location.

The failed attempt captured no actual waiter row; the specific waiter was not observed live and must not be claimed as such. This attribution is supported by the exact panic and unchanged source ordering, not by fabricated waiting-query evidence.

Independent record: review/PROBE17_INDEPENDENT_ATTRIBUTION.json. Runner record: tests/attempt2/PROBE17_READONLY_ATTRIBUTION.json. Original STOP/dump receipts retained;27 owned DBs dumped/validated and PG stopped3/2.

DISPOSITION = HARNESS_ONLY_SYNCHRONIZATION_SELECTOR_ERROR; NO_OBSERVED_PRODUCT_SEMANTIC_FAILURE; NO_FOURTH_LAYER
AUTHORIZED_CORRECTION = only snapshot.rs test barrier: exact blocker backendPID, sameDB active reader, pg_blocking_pids link, ungranted AccessShareLock for the precise transition relation, exact early integrity-query match. Capture actual waiter evidence before Owner mutation. Retain bounded timeout diagnostics, release/abort on timeout, old snapshot action assertions, actual Owner commit, fresh404 and actual cancel403 with zero runtime delta. No product source change.
NEXT = independent final patch review + no-run and binary hash, then explicitly authorized local attempt3 only17 onward; reuse first16 unchanged successful probes. New true semantic failures still stop immediately.

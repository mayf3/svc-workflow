# Probe11 attempt1 disposition

Root independently parsed the preserved Rust Debug before/after values from probe-11.log (SHA2564ddc5eae6416358ab1abb61bf04d246bfa356a308dae5dc6f5f9f8937e031c78). The same-body replay all-table equality at guards.rs43 passed. The panic is at45:97, after a changed-body same-key request correctly returned409 idempotency_conflict.

All32 tables were compared. Only workflow_command_attempt_audits changed, from[] to one IDEMPOTENCY_CONFLICT row; the other31 tables are exactly equal, including all business facts, original receipts, activations, closures and outbox. Accepted WORKFLOW_TRANSITION_CONTRACT_V0_1.md:304 explicitly requires Different hash -> IdempotencyConflict + CommandAttemptAudit. Baseline helpers/receipt and candidate are byte-identical; the transaction commit preserving this audit is unchanged.

Independent non-author review: review/PROBE11_INDEPENDENT_ATTRIBUTION.json. Runner attribution: tests/PROBE11_READONLY_ATTRIBUTION.json. Root independent parse: tests/PROBE11_ROOT_DIFF.json. These are separate actual read-only derivations from the original raw log, not a replayed test.

DISPOSITION = HARNESS_ONLY_TEST_EXPECTATION_ERROR; NOT_NEW_PRODUCT_SEMANTIC_FAILURE; NOT_FOURTH_LAYER
MUTATION_AUTHORIZATION = current mandate permits correction of this new test to the already accepted audit contract, with no product change or scope expansion.
MINIMAL_CORRECTION = retain same-body replay full-table equality; after changed-body409 assert exactly one added audit with original receipt/command, actor/key/old-new hash/type/details/reason binding and every other table unchanged. Preserve original failure/STOP receipts/dumps. Independently review corrected probe before a separately recorded local attempt2.
REUSE = first10 frozen probes passed on unchanged source/test hashes; do not rerun them. After correction rerun exact11, then unrun12..19, four additional reviewed acceptance probes, and affected existing regression. No production write/deploy/merge.

Owned fixture was stopped after attempt1 and20 dumps validated. A later explicit runner authorization may restart only that same local owned fixture. A true new semantic failure still immediately stops dependent work.

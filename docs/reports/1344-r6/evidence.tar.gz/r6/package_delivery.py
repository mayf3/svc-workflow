"""Package bounded, credential-free local verification evidence for the PR."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path('/tmp/sw-d6-fix')
EVIDENCE = Path('/tmp/sw-aa-r6-evidence')
DEST = ROOT / 'docs/reports/1344-r6'
DEST.mkdir(parents=True, exist_ok=True)
files = {}

def add(path, name):
    if path.is_file():
        files[name] = path.read_bytes()

def tree(path, prefix):
    for f in sorted(path.rglob('*')):
        rel = f.relative_to(path)
        if path == EVIDENCE and str(rel) in {'tests/run.sh', 'tests/reproduce.py', 'tests/REPRODUCE.md'}:
            continue  # Superseded, unexecuted single-DSN drafts are not delivery tools.
        if any(p in {'dumps', 'pgdata', 'target', 'node_modules', '__pycache__'} for p in rel.parts):
            continue
        if f.suffix not in {'.json', '.jsonl', '.log', '.rc', '.md', '.py', '.patch', '.txt', '.sh', '.raw'}:
            continue
        add(f, prefix + '/' + str(rel))

tree(EVIDENCE, 'r6')
tree(Path('/tmp/sw-aa-r5-evidence/sdk'), 'r5/sdk')
tree(Path('/tmp/sw-aa-r5-evidence/naming/baseline'), 'naming/baseline')
for name in ['inventory_names.py', 'INVENTORY_METHOD.md', 'WIRE_WHITELIST.json', 'COMPARATOR_SELF_CHECK.json', 'INDEPENDENT_NAMING_SOURCE_REVIEW.json']:
    add(Path('/tmp/sw-aa-r5-evidence/naming') / name, 'naming/' + name)
for name in ['red', 'extended-red']:
    tree(Path('/tmp/sw-aa-r4-evidence') / name, 'r4/' + name)
for f in sorted(Path('/tmp/sw-aa-r4-evidence').iterdir()):
    if f.name == 'http-red.log' or f.name.startswith(('matrix-red-', 'extended-red-', 'MATRIX_RED_', 'EXTENDED_RED_', 'RED_')):
        if f.suffix in {'.log', '.rc', '.json', '.md'}:
            add(f, 'r4/' + f.name)
for name in ['CONFORMANCE_RECORD.md', 'REGRESSION_SUMMARY.json']:
    add(Path('/tmp/sw-wpe-evidence') / name, 'historical-1348/' + name)

# Only runtime records are scanned: source and patches can contain token
# construction code, while credential values must never enter this archive.
import re
secret = re.compile(rb'eyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}|-----BEGIN (?:RSA |EC )?PRIVATE KEY-----|postgres(?:ql)?://[^/@\s:]+:[^/@\s]+@|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}')
source_inventories = {name for name in files if name.endswith('/raw-literals-per-module.json')}
violations = [name for name, data in files.items() if name.endswith(('.json', '.jsonl', '.log', '.raw')) and name not in source_inventories and secret.search(data)]
assert not violations, violations

index = {
    'scope': 'Local source and isolated fixture verification; no production acceptance',
    'excluded': ['database dump payloads (local paths/hashes and validation receipts retained)', 'pgdata', 'build artifacts', 'dependencies', 'runtime credentials', 'superseded unexecuted single-DSN reproduction drafts'],
    'runtime_secret_scan': 'PASS_FOR_RUNTIME_RECORDS',
    'runtime_scan_source_inventory_exclusions': sorted(source_inventories),
    'source_inventory_note': 'Unmodified lexical source inventories contain existing loopback test-connection literals in provisioning tests and pool tests; these are source examples, not captured runtime credentials. Original bytes and hashes are retained.',
    'files': {name: {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)} for name, data in sorted(files.items())},
}
manifest = json.dumps(index, indent=2, ensure_ascii=False).encode() + b'\n'
files['EVIDENCE_INDEX.json'] = manifest
out = DEST / 'evidence.tar.gz'
with out.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as archive:
            for name, data in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(data))
summary = {'archive': out.name, 'sha256': hashlib.sha256(out.read_bytes()).hexdigest(), 'bytes': out.stat().st_size, 'file_count': len(files), 'runtime_secret_scan': 'PASS_FOR_RUNTIME_RECORDS'}
(DEST / 'evidence-index.json').write_text(json.dumps(summary, indent=2) + '\n')
with tarfile.open(out, 'r:gz') as archive:
    assert len(archive.getmembers()) == len(files)
    for member in archive.getmembers():
        assert archive.extractfile(member).read() == files[member.name], member.name
print(json.dumps(summary))

from pathlib import Path
import json,hashlib,datetime,subprocess,re
base=Path('/tmp/sw-aa-r6-evidence/tests'); run=base/'attempt3'; raw=run/'frozen-green'; out=Path('/tmp/sw-aa-r6-evidence/review')
def load(name):return json.loads((raw/(name+'.json')).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
consumed={}
def bind(p):consumed[str(p)]=sha(p)
def read(name):p=raw/(name+'.json');bind(p);return json.loads(p.read_text())
cmdp=run/'commands.json';bind(cmdp);commands=json.loads(cmdp.read_text()); selected=[]
for n in [17,20,21,22]:
 c=next(c for c in commands if c['label']==f'probe-{n}'); assert c['rc']==0;cpath=Path(c['log']);assert sha(cpath)==c['log_sha256'];bind(cpath);assert '1 passed; 0 failed' in cpath.read_text(); selected.append(c)
source_snapshot=base/'ATTEMPT3_TEST_SOURCE_SNAPSHOT.json';bind(source_snapshot);snap=json.loads(source_snapshot.read_text())
for f in ['tests/authorized_actions_r4/coverage.rs','tests/authorized_actions_r4/snapshot.rs']:
 p=Path('/tmp/sw-aa-r5-tests')/f;assert sha(p)==snap['test_files'][f];bind(p)
# Offline dump reads only: never connects or restores into a database.
restore='/opt/homebrew/Cellar/postgresql@16/16.15/bin/pg_restore'
def unescape(v):
 if v==r'\N':return None
 mapping={'n':'\n','r':'\r','t':'\t','b':'\b','f':'\f','v':'\v','\\':'\\'}
 return re.sub(r'\\(.)',lambda m:mapping.get(m[1],m[1]),v)
def table(dump,table_name):
 bind(dump)
 text=subprocess.check_output([restore,'--data-only','--table='+table_name,'--file=-',str(dump)],text=True)
 lines=text.splitlines(); rows=[];cols=None
 for line in lines:
  if line.startswith('COPY public.'+table_name+' '):cols=line.split('(',1)[1].split(')',1)[0].split(', ');continue
  if cols is None:continue
  if line==r'\.':break
  vals=line.split('\t');assert len(vals)==len(cols),(table_name,len(vals),len(cols));rows.append({k:unescape(v) for k,v in zip(cols,vals)})
 return rows
# Probe17 exact captured waiter/result.
w=read('snapshot-owner-observed-reader');owner=read('snapshot-owner')
assert w==owner['observed_reader'];assert w['reader_pid']!=w['expected_blocker_pid'];assert w['expected_blocker_pid'] in w['blocker_pids'];assert w['mode']=='AccessShareLock' and w['granted'] is False;assert w['relation_name']=='workflow_transition_definitions';assert w['state']=='active' and w['wait_event_type']=='Lock' and w['backend_xmin'];assert 'FROM workflow_submissions s' in w['query'] and 'LEFT JOIN workflow_transition_definitions t' in w['query']
assert owner['old_snapshot']['detail']['authorized_actions']==[{'operation':'cancel','request_validation':'REQUIRED_AT_EXECUTION'}]
assert owner['fresh_status']==404 and owner['fresh_response']['error']['code']=='workflow_instance_not_found_or_not_visible';assert owner['execute_refusal']['error']['code']=='not_domain_owner';assert all(owner['before'][k]==owner['after'][k] for k in ['instance','events','visits','submissions'])
# Probe20 DRAFT and independent completed refusal receipt.
for name,ops in [('draft-published-control',['transition','request_assistance']),('draft-agent-detail',['request_assistance']),('draft-owner-detail',['cancel'])]:
 d=read(name);assert d['before']==d['after'];assert [a['operation'] for a in d['detail']['authorized_actions']]==ops
assert read('draft-agent-detail')['detail']['instance']['definition_version_status']=='DRAFT'
r=read('draft-original-writer-refusal');assert r['status']==500 and r['response']['error']['code']=='internal_consistency_error'
assert read('draft-failure-receipt')['receipt']==[1,500,'definition_version_draft']
dbid=read(next(x.stem for x in raw.glob('database-aa_r4_draftdef_*.json')))['database'];dump=run/'dumps'/(dbid+'.dump');instance=r['before']['instance']['workflow_instance_id']
inst=next(x for x in table(dump,'workflow_instances') if x['workflow_instance_id']==instance); assert int(inst['workflow_state_version'])==r['before']['instance']['workflow_state_version']
receipts=table(dump,'workflow_command_receipts');denial=[x for x in receipts if x['command_type']=='EXECUTE_WORKFLOW_TRANSITION'];assert len(denial)==1 and denial[0]['receipt_status']=='COMPLETED' and denial[0]['response_status']=='500' and json.loads(denial[0]['response_body'])['error']=='definition_version_draft'
for table_name,before_key in [('workflow_events','events'),('workflow_node_visits','visits'),('workflow_submissions','submissions')]:assert len([x for x in table(dump,table_name) if x['workflow_instance_id']==instance])==len(r['before'][before_key])
# Probe21 two actual concurrent writes vs old/fresh snapshot, then real cap.
rr=[]
for mode,delta,status in [('case',1,201),('return',2,200)]:
 r=read('snapshot-'+mode+'-result');before=read('snapshot-'+mode+'-before');fresh=read('snapshot-'+mode+'-fresh');assert before['before']==before['after'] and fresh['before']==fresh['after'];assert r['observed_rr_wait'] is True;assert r['old_snapshot']['detail']==before['detail'];assert r['fresh']==fresh['detail'];v=before['detail']['instance']['workflow_state_version'];assert r['fresh']['instance']['workflow_state_version']==v+delta;assert r['mutation_status']==status and r['mutation_response']['workflowStateVersion']==v+delta;assert r['fresh']['authorized_actions_status']=='NONE_FOR_ACTOR' and r['fresh']['authorized_actions']==[];assert r['stale_refusal']['error']['code']=='workflow_state_version_conflict';assert r['stale_refusal']['error']['details']=={'actual':v+delta,'expected':v};assert r['current_refusal']['error']['code']=='assistance_open';rr.append({'mode':mode,'old_version':v,'new_version':v+delta,'mutation_http':status,'rr_observed':True})
r=read('snapshot-return-result');ret=r['mutation_request']['transitionDefinitionId'];case=r['mutation_response']['returnPolicyEscalation']['assistanceCaseId'];resolve=read('snapshot-return-resolve');advance=read('snapshot-return-final-reentry');cap=read('snapshot-return-cap-after-resolution');assert resolve['status']==200 and resolve['request']['expectedWorkflowStateVersion']==8 and resolve['response']['workflowStateVersion']==9;assert advance['status']==200 and advance['request']['expectedWorkflowStateVersion']==9 and advance['response']['workflowStateVersion']==10;assert cap['detail']['instance']['workflow_state_version']==10;assert not any(x.get('transition_id')==ret for x in cap['detail']['authorized_actions']);assert cap['before']==cap['after']
dbid=read(next(x.stem for x in raw.glob('database-aa_r4_snapshotreturn_*.json')))['database'];dump=run/'dumps'/(dbid+'.dump');events=table(dump,'workflow_events');returns=[x for x in events if x['transition_effect']=='RETURN' and json.loads(x['event_data']).get('transition_definition_id')==ret];assert len(returns)==3
receipts=table(dump,'workflow_command_receipts');exhausted=[x for x in receipts if x['command_type']=='EXECUTE_WORKFLOW_TRANSITION' and x['response_status']=='409' and json.loads(x['response_body']).get('error')=='return_policy_exhausted'];assert len(exhausted)==1 and exhausted[0]['receipt_status']=='COMPLETED'
# Probe22 persisted future eligibility remains orthogonal to transition.
t=read('time-persisted-fact-and-transition');d=read('time-real-waiting-detail');write=read('time-independent-transition-allowed');assert d['before']==d['after'];assert d['detail']['current_visit']['eligibility']==t['projected'];assert t['projected']=={'classification':'WAITING_FOR_TIME','nextEligibleAt':t['future']};assert t['closure_count']==1 and t['eligibility_fact_retained'] is True;assert write['status']==200 and write['request']['expectedWorkflowStateVersion']==1 and write['response']['workflowStateVersion']==2;future=datetime.datetime.fromisoformat(t['future'].replace('Z','+00:00'));when=datetime.datetime.fromisoformat(next(x for x in selected if x['label']=='probe-22')['at'].replace('Z','+00:00'));assert future>when
eligibility=d['before']['workflow_dispatch_eligibility_events'];assert any(x['eligibility_event_id']==t['eligibility_event_id'] and x['activation_id']==t['activation_id'] for x in eligibility)
dbid=read(next(x.stem for x in raw.glob('database-aa_r4_waitingtime_*.json')))['database'];dump=run/'dumps'/(dbid+'.dump');closures=table(dump,'workflow_activation_closures');assert len([x for x in closures if x['activation_id']==t['activation_id'] and x['closure_reason']=='TRANSITIONED'])==1;retained=table(dump,'workflow_dispatch_eligibility_events');assert any(x['eligibility_event_id']==t['eligibility_event_id'] and x['activation_id']==t['activation_id'] for x in retained)
report={'SPEC_GOVERNANCE_MODE':'REVIEW','REVIEW_KIND':'AFFECTED_CONTRACT','reviewer':'/root/sdk_align','AUTHOR_INDEPENDENCE':'PASS for executed probes and readbacks; no probe authoring or DB execution by reviewer','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'NewDRAFT/case+RETURN/futuretime probes and corrected Owner RR observer; cleanup runtime still PENDING after original visibility harness failure','review_result':'PARTIAL_PASS; CLEANUP_PENDING','product_coordinates':'CANDIDATE_SOURCE_SNAPSHOT.json and ATTEMPT3_TEST_SOURCE_SNAPSHOT.json; final Git head not yet supplied','verified':{'probe17_owner_snapshot':{'reader_pid':w['reader_pid'],'expected_blocker_pid':w['expected_blocker_pid'],'backend_xmin':w['backend_xmin'],'wait_relation':w['relation_name'],'old_cancel_projection':True,'fresh404':True,'actual_cancel403_zero_runtime':True},'probe20_DRAFT':{'http':500,'completed_failure_receipt':'definition_version_draft','independent_assistance_and_cancel_retained':True,'offline_dump_runtime_counts_unchanged':True},'probe21_case_RETURN':{'cases':rr,'return_event_count':3,'owner_resolution_then_reentry_versions':[8,9,10],'cap_excluded':True,'completed_original_writer_cap_receipt':'return_policy_exhausted'},'probe22_future_time':{'projected':t['projected'],'future_at_execution':True,'actual_transition_http':200,'state_version':2,'closure_once':True,'persisted_eligibility_retained':True},'probe23_cleanup':'PENDING corrected7b978087 source compile/execution; original probe23 failure preserved and not represented as PASS'},'runtime_limit':'Isolated loopback PostgreSQL plus real application HTTP router/JWKS tests; no production writes or production/deployment acceptance. Reviewer read only saved artifacts and offline pg_restore COPY output, no DB connection/restore.','commands':selected,'evidence_sha256':consumed,'old_failure_handling':'All original harness failures remain preserved; no unknown original waiter or pre-failure business step is invented.'}
(out/'EXECUTED_COVERAGE_REVIEW.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'path':str(out/'EXECUTED_COVERAGE_REVIEW.json'),'result':report['review_result'],'verified':report['verified']},indent=2))

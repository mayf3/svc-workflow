# #1344 r6 bounded continuation

SPEC_GOVERNANCE_MODE = PREFLIGHT
TARGET_REPOSITORY = mayf3/svc-workflow
REVIEW_TARGET_HEAD = d9ebad8db87356eac128e1858ee8f8a2ba1eda73 plus INITIAL_COORDINATES.json frozen r5 candidate
BASE_HEAD = b32c0d1a82abeafbf993c5638bbc9f55e436d9a1
CURRENT_BASE_HEAD = b32c0d1a82abeafbf993c5638bbc9f55e436d9a1 (fresh ls-remote)
ROUTE_STAGE = IMPLEMENTATION
AUTHORITY_ACCEPTED_IN_BASE = YES
GOAL_OR_TARGET = Preserve A/B, align strict SDK current_visit with recorded real detail, complete accepted AA, validate, commit/push/open main PR and record four sections plus exact head on agent-control#1344.
CURRENT_GAP = Real current_visit fixture rejects existing assignee_canonical_agent_id and eligibility; AA execution acceptance remains pending.
OBSERVATIONS = d9ebad8d is preserved r5 A/B commit, parent725c7996 predicate extraction, parentb32c0d1a main; governance verification rc0 and accepted adoption/AA merge ancestry rc0. Fresh PR114 merged readback and Owner6552672226 exact-head acceptance verified.
WORKING_GUESS = No additional scope needed; contingent on tests and independent review.
AUTHORITY_ACTION = REUSE
PRIMARY_AUTHORITY = WORKFLOW_INSTANCE_AUTHORIZED_ACTIONS_V1@69ce065c00082c01c3dc03defc72e46a7d0d18a1 (merge108a47a5; SHA256bd49f9ddceaa5d78ff5246d0782197e7530929ae54befa61be824ff316251e43)
RELATED_AUTHORITIES = ProductV13; Architecture0.4.7; VAI3; ExecutionControl2; GCR2; OwnerObligation3; Coordinator1; WEC1; WEP2; accepted HTTP bundle and WPE1 explicit AA lifecycle-metadata disposition. r5 authority review retained.
IMPLEMENTATION_AUTHORITY = contracts
ATOMIC_SPEC_IMPLEMENTATION_PERMITTED = NO
PLAN_LEVEL = EXEC_PLAN
ASSURANCE_LEVEL = CONTROLLED
EXECUTION_MANDATE = VALID (current user continuation and one-time SDK expansion)
MUTATION_AUTHORIZATION = VALID for scoped isolated implementation/tests and named GitHub delivery only
ISOLATED_WRITE_SURFACE = /tmp/sw-d6-fix ac-d6d11-impl-r4 Root sole source integrator; SDK helper new isolated worktree; test helper existing isolated r5 overlay worktree
CONTROLLED_RUNBOOK_REQUIRED = YES for local fixture and GitHub delivery, below
SPEC_GAP_DEPENDENCY = NONE
EVIDENCE_REVIEWABILITY = PASS; raw logs/fixtures/hashes retained locally and selected sanitized evidence committed for PR reviewers
LIVE_AUTHORITY_GAP = NONE within this source-only task
OWNER_DECISION_REQUIRED = NO
EMERGENCY_STATE = NONE
BASE_IMPACT = NONE at preflight; fresh recheck before delivery
IMPLEMENTATION_ALLOWED = YES
MERGE_READY = NO until validation/review; merge execution never authorized
OPERATION_ALLOWED = isolated fixture + explicitly requested GitHub push/open/comment only
EVIDENCE_NEEDED = SDK real fixture RED/GREEN and strict unknown fields; accepted ACC001..007; existing failure names equal baseline; canonical business names per logical module/global equal baseline; OpenAPI/digests/SDK suite/build; independent exact candidate review and delivery readback
DONE_WHEN = scoped candidate validated/reviewed, committed/pushed, open main PR with A/B/SDK/AA sections, #1344 exact-head receipt read back, owned fixture safely stopped
EXPANSION_TRIGGER = any new semantic failure outside the adjudicated SDK/A/B/AA scope, writer semantics drift, non-whitelisted business name/permission/error/entity/route, relevant authority/base conflict
NEXT_REAL_ACTION = real-fixture strict SDK RED/GREEN, then preserved HTTP overlays
NEXT_ACTION = CONTINUE

1. Freeze original source/status/hashes and retain all r4/r5 evidence. Preserve A/B commit unchanged.
2. SDK helper records RED on actual fixture, adds only observed existing fields and strict observed nested shape, validates GREEN and unknown-key rejection. Root integrates only new SDK/test/fixture delta.
3. Test helper snapshots integrated source into existing isolated test worktree, compiles and runs frozen probes sequentially on owned loopback PostgreSQL. Any semantic failure immediately halts dependent business tests and triggers truthful STOP; harness/compiler failures require explicit recorded diagnosis before correction.
4. Complete only accepted AA implementation gaps identified by review. No changes to existing writer behavior. Execute spec-required and appropriate existing regressions, retaining known failure names without rename/skip/filter waivers. Review canonical naming and broad appendices.
5. Persist conformance evidence, stage/commit, independent final exact-head review, fresh main impact check, push origin only, open PR against main and comment agent-control#1344 with four results/exact head. No merge/deploy.

## Controlled operation bounds

Actor = Root and named local test helper; environment = /tmp worktrees, disposable PostgreSQL role swaar4 at127.0.0.1:55483, owned PGDATA /tmp/sw-aa-r4-evidence/pgdata. No production service credentials/endpoints/SSH remotes used. Inspect local PG ownership/listener/status before starting; retain prior11 DB/dump records. Execute one sequential test attempt per fixed candidate; rerun only after justified compiler/harness/source correction. On STOP cease business tests, dump/validate any newly changed owned DBs and gracefully stop owned server, verify no listener. Never replay production operations.

Secrets = only local test credentials/ephemeral JWTs, absent from committed/public evidence. Receipts record commands, rc, source hashes, request/response readbacks and limits. GitHub effects limited to authorized branch push, open PR, requested issue receipt; no merge/deployment/remote runtime actions. Recheck remote main/head before write and read back resulting PR/comment/head.

Model disposition = RETAIN supported legacy diagnostics and dedicated managed/GCR/scheduler surfaces; reuse extracted per-operation predicates, no second permission model. SDK existing current_visit fields are supported response representation, no compatibility fallback or new server fields.
